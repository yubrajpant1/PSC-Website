import React, { useState } from 'react';
import { X, Mail, Lock, User, GraduationCap, ArrowRight, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Logo } from '../common/Logo';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'login' | 'signup' | 'reset';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'login',
}) => {
  const { login, signup, isSupabaseActive } = useAuth();
  const [tab, setTab] = useState<'login' | 'signup' | 'reset'>(initialTab);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [targetExam, setTargetExam] = useState('Civil Engineering 5th Level');
  
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');
    setLoading(true);

    try {
      if (tab === 'login') {
        const res = await login(email, password);
        if (res.error) {
          setErrorMessage(res.error);
        } else {
          setSuccessMessage('Successfully logged in!');
          setTimeout(() => {
            onClose();
          }, 600);
        }
      } else if (tab === 'signup') {
        if (!fullName.trim()) {
          setErrorMessage('Please enter your full name');
          setLoading(false);
          return;
        }
        if (password.length < 6) {
          setErrorMessage('Password must be at least 6 characters');
          setLoading(false);
          return;
        }
        const res = await signup(email, password, fullName, targetExam);
        if (res.error) {
          setErrorMessage(res.error);
        } else {
          setSuccessMessage('Account registered successfully! Welcome to Lokesewa Edge.');
          setTimeout(() => {
            onClose();
          }, 800);
        }
      } else if (tab === 'reset') {
        // Password reset flow
        if (!email) {
          setErrorMessage('Please provide your registered email address.');
          setLoading(false);
          return;
        }
        setSuccessMessage('Password reset instructions have been sent to ' + email);
        setTimeout(() => {
          setTab('login');
        }, 2000);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = async (role: 'student' | 'admin') => {
    setLoading(true);
    if (role === 'admin') {
      await login('admin@loksewaedge.com', 'admin123');
    } else {
      await login('student@loksewaedge.com', 'pass123');
    }
    setLoading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header Ribbon */}
        <div className="bg-slate-900 p-6 text-white text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex justify-center mb-2">
            <Logo size="md" light showTagline={false} />
          </div>
          <p className="text-xs text-slate-300 mt-1">
            {tab === 'login' && 'Sign in to access bookmarked notes, quiz stats & tests'}
            {tab === 'signup' && 'Create your free student account for Nepal PSC exams'}
            {tab === 'reset' && 'Reset your password'}
          </p>

          {/* Supabase Status Pill */}
          <div className="mt-3 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-white/10 text-slate-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isSupabaseActive ? 'Supabase Auth Connected' : 'Local Preview Auth Enabled'}</span>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200">
          <button
            type="button"
            onClick={() => { setTab('login'); setErrorMessage(''); }}
            className={`flex-1 py-3 text-sm font-semibold transition-colors ${
              tab === 'login'
                ? 'text-orange-600 border-b-2 border-orange-600 bg-orange-50/30'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => { setTab('signup'); setErrorMessage(''); }}
            className={`flex-1 py-3 text-sm font-semibold transition-colors ${
              tab === 'signup'
                ? 'text-orange-600 border-b-2 border-orange-600 bg-orange-50/30'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Register Student
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {errorMessage && (
            <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 flex items-start gap-2.5 text-red-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 flex items-start gap-2.5 text-emerald-700 text-xs">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {tab === 'signup' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Name (पूरा नाम)
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ramesh Karki"
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Target PSC Examination (तयारी गरिरहेको परीक्षा)
                  </label>
                  <div className="relative">
                    <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <select
                      value={targetExam}
                      onChange={e => setTargetExam(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-white"
                    >
                      <option value="Civil Engineering 5th Level">Civil Engineering 5th Level (Sub-Engineer)</option>
                      <option value="Civil Engineering 7th Level">Civil Engineering 7th Level (Engineer)</option>
                      <option value="Nayab Subba (Non-Gazetted 1st)">Nayab Subba (Non-Gazetted 1st)</option>
                      <option value="Kharidar (Non-Gazetted 2nd)">Kharidar (Non-Gazetted 2nd)</option>
                      <option value="Section Officer (Sakha Adhikrit)">Section Officer (Sakha Adhikrit)</option>
                      <option value="Health Services / Staff Nurse">Health Services / Staff Nurse</option>
                      <option value="Nepal Rastra Bank / Banking">Banking & Public Enterprises</option>
                    </select>
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>
            </div>

            {tab !== 'reset' && (
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-semibold text-slate-700">
                    Password
                  </label>
                  {tab === 'login' && (
                    <button
                      type="button"
                      onClick={() => setTab('reset')}
                      className="text-xs text-orange-600 hover:text-orange-700 hover:underline"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-lg shadow-sm hover:shadow transition flex items-center justify-center gap-2 text-sm disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <span>Please wait...</span>
              ) : (
                <>
                  <span>
                    {tab === 'login' && 'Sign In to Account'}
                    {tab === 'signup' && 'Create Student Account'}
                    {tab === 'reset' && 'Send Password Reset Link'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Options */}
          <div className="mt-5 pt-4 border-t border-slate-100">
            <p className="text-[11px] font-medium text-slate-400 text-center uppercase tracking-wider mb-2.5">
              Instant Demo Access
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('student')}
                className="py-1.5 px-3 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md font-medium transition cursor-pointer text-center"
              >
                Sign in as Student
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('admin')}
                className="py-1.5 px-3 text-xs bg-navy-50 hover:bg-slate-800 bg-slate-800 text-white rounded-md font-medium transition cursor-pointer text-center"
              >
                Sign in as Admin
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { Hero } from './components/home/Hero';
import { CategoryGrid } from './components/home/CategoryGrid';
import { FeaturedMaterials } from './components/home/FeaturedMaterials';
import { LatestNoticesSection } from './components/home/LatestNoticesSection';
import { QuickQuizBanner } from './components/home/QuickQuizBanner';
import { MaterialsPage } from './components/materials/MaterialsPage';
import { McqPracticePage } from './components/mcq/McqPracticePage';
import { GkCurrentAffairsPage } from './components/gk/GkCurrentAffairsPage';
import { NoticesPage } from './components/notices/NoticesPage';
import { StudentDashboard } from './components/student/StudentDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AuthModal } from './components/auth/AuthModal';
import { PdfViewerModal } from './components/materials/PdfViewerModal';
import { StudyMaterial, SubjectCategory } from './types';

function MainApp() {
  const [currentView, setCurrentView] = useState<'home' | 'materials' | 'mcq' | 'gk' | 'notices' | 'dashboard' | 'admin'>('home');
  const [materialsCategoryFilter, setMaterialsCategoryFilter] = useState<SubjectCategory | 'all'>('all');

  // Modals
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authTab, setAuthTab] = useState<'login' | 'signup'>('login');
  const [selectedMaterialForPreview, setSelectedMaterialForPreview] = useState<StudyMaterial | null>(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  // Scroll to top on navigation
  const handleNavigate = (view: string, params?: { category?: SubjectCategory; searchQuery?: string }) => {
    if (params?.category) {
      setMaterialsCategoryFilter(params.category);
    }
    setCurrentView(view as any);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAuth = (tab: 'login' | 'signup' = 'login') => {
    setAuthTab(tab);
    setIsAuthOpen(true);
  };

  const handleOpenMaterialPreview = (material: StudyMaterial) => {
    setSelectedMaterialForPreview(material);
    setIsPdfModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      {/* Navigation Header */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenAuth={handleOpenAuth}
      />

      {/* Main Routed Content */}
      <main className="flex-1">
        {currentView === 'home' && (
          <>
            <Hero
              onExploreMaterials={() => handleNavigate('materials')}
              onPracticeMcqs={() => handleNavigate('mcq')}
              onSearch={query => {
                handleNavigate('materials');
              }}
            />

            <CategoryGrid
              onSelectCategory={category => {
                setMaterialsCategoryFilter(category);
                handleNavigate('materials', { category });
              }}
            />

            <FeaturedMaterials
              onViewMaterial={handleOpenMaterialPreview}
              onViewAllMaterials={() => handleNavigate('materials')}
            />

            <QuickQuizBanner
              onStartQuiz={() => handleNavigate('mcq')}
            />

            <LatestNoticesSection
              onViewAllNotices={() => handleNavigate('notices')}
            />
          </>
        )}

        {currentView === 'materials' && (
          <MaterialsPage initialCategory={materialsCategoryFilter} />
        )}

        {currentView === 'mcq' && (
          <McqPracticePage
            onNavigateToNotes={() => handleNavigate('materials')}
          />
        )}

        {currentView === 'gk' && (
          <GkCurrentAffairsPage />
        )}

        {currentView === 'notices' && (
          <NoticesPage />
        )}

        {currentView === 'dashboard' && (
          <StudentDashboard onNavigate={handleNavigate} />
        )}

        {currentView === 'admin' && (
          <AdminDashboard />
        )}
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        initialTab={authTab}
      />

      {/* Global PDF Viewer Modal */}
      <PdfViewerModal
        material={selectedMaterialForPreview}
        isOpen={isPdfModalOpen}
        onClose={() => {
          setIsPdfModalOpen(false);
          setSelectedMaterialForPreview(null);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <MainApp />
      </DataProvider>
    </AuthProvider>
  );
}

import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  isSupabaseActive: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  signup: (email: string, password: string, fullName: string, targetExam?: string) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error?: string }>;
  switchDemoRole: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_STORAGE_USER_KEY = 'loksewa_auth_user';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const isSupabaseActive = isSupabaseConfigured();

  // Load initial session
  useEffect(() => {
    let mounted = true;

    async function initAuth() {
      try {
        const client = supabase;
        if (isSupabaseActive && client) {
          const { data: { session } } = await client.auth.getSession();
          if (session?.user) {
            // Fetch profile
            const { data: profile } = await client
              .from('profiles')
              .select('*')
              .eq('id', session.user.id)
              .single();

            if (mounted) {
              if (profile) {
                setUser(profile as UserProfile);
              } else {
                // Profile might be in creation or default to student
                const newProfile: UserProfile = {
                  id: session.user.id,
                  email: session.user.email || '',
                  full_name: session.user.user_metadata?.full_name || 'Loksewa Aspirant',
                  role: (session.user.user_metadata?.role as UserRole) || 'student',
                  target_exam: session.user.user_metadata?.target_exam || 'Civil Engineering 5th Level',
                  created_at: session.user.created_at,
                };
                setUser(newProfile);
              }
            }
          } else {
            if (mounted) setUser(null);
          }

          // Listen to auth changes
          const { data: { subscription } } = client.auth.onAuthStateChange(async (_event, session) => {
            if (session?.user) {
              const { data: profile } = await client
                .from('profiles')
                .select('*')
                .eq('id', session.user.id)
                .single();

              if (mounted) {
                if (profile) {
                  setUser(profile as UserProfile);
                } else {
                  setUser({
                    id: session.user.id,
                    email: session.user.email || '',
                    full_name: session.user.user_metadata?.full_name || 'Loksewa Aspirant',
                    role: (session.user.user_metadata?.role as UserRole) || 'student',
                    target_exam: session.user.user_metadata?.target_exam || 'Civil Engineering 5th Level',
                    created_at: session.user.created_at,
                  });
                }
              }
            } else {
              if (mounted) setUser(null);
            }
          });

          return () => {
            subscription.unsubscribe();
          };
        } else {
          // Local storage session fallback
          const localUserStr = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
          if (localUserStr) {
            try {
              const parsed = JSON.parse(localUserStr);
              if (mounted) setUser(parsed);
            } catch {
              localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
            }
          }
        }
      } catch (err) {
        console.warn('Auth initialization notice:', err);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    initAuth();

    return () => {
      mounted = false;
    };
  }, [isSupabaseActive]);

  const login = async (email: string, password: string): Promise<{ error?: string }> => {
    if (isSupabaseActive && supabase) {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) {
        return { error: error.message };
      }
      return {};
    } else {
      // Local mode authentication
      const isMockAdmin = email.toLowerCase().includes('admin');
      const mockUser: UserProfile = {
        id: 'local-user-' + Date.now(),
        email,
        full_name: isMockAdmin ? 'Administrator (Loksewa Edge)' : 'Subhash Poudel',
        role: isMockAdmin ? 'admin' : 'student',
        target_exam: isMockAdmin ? undefined : 'Civil Sub-Engineer (5th Level)',
        phone: '9841000000',
        created_at: new Date().toISOString(),
      };
      setUser(mockUser);
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(mockUser));
      return {};
    }
  };

  const signup = async (
    email: string,
    password: string,
    fullName: string,
    targetExam?: string
  ): Promise<{ error?: string }> => {
    if (isSupabaseActive && supabase) {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            role: 'student',
            target_exam: targetExam || 'Civil Engineering 5th Level',
          },
        },
      });

      if (error) {
        return { error: error.message };
      }

      if (data.user) {
        const profile: UserProfile = {
          id: data.user.id,
          email: data.user.email || email,
          full_name: fullName,
          role: 'student',
          target_exam: targetExam || 'Civil Engineering 5th Level',
          created_at: new Date().toISOString(),
        };
        setUser(profile);
      }
      return {};
    } else {
      const mockUser: UserProfile = {
        id: 'local-user-' + Date.now(),
        email,
        full_name: fullName,
        role: 'student',
        target_exam: targetExam || 'Civil Engineering 5th Level',
        created_at: new Date().toISOString(),
      };
      setUser(mockUser);
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(mockUser));
      return {};
    }
  };

  const logout = async () => {
    if (isSupabaseActive && supabase) {
      await supabase.auth.signOut();
    }
    setUser(null);
    localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
  };

  const updateProfile = async (updates: Partial<UserProfile>): Promise<{ error?: string }> => {
    if (!user) return { error: 'No user signed in' };

    const updatedUser = { ...user, ...updates };
    setUser(updatedUser);

    if (isSupabaseActive && supabase) {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);

      if (error) return { error: error.message };
    } else {
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(updatedUser));
    }

    return {};
  };

  // Quick helper to switch role for demo/testing without signing out
  const switchDemoRole = (role: UserRole) => {
    const updated: UserProfile = user
      ? { ...user, role }
      : {
          id: 'demo-user-1',
          email: role === 'admin' ? 'admin@loksewaedge.com' : 'student@loksewaedge.com',
          full_name: role === 'admin' ? 'Admin Officer' : 'Bikash Sharma',
          role,
          target_exam: role === 'admin' ? undefined : '5th Level Civil Sub-Engineer',
          created_at: new Date().toISOString(),
        };
    setUser(updated);
    localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(updated));
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isSupabaseActive,
        isAdmin,
        login,
        signup,
        logout,
        updateProfile,
        switchDemoRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

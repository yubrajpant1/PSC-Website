import React, { useState, useMemo } from 'react';
import {
  Globe,
  Flame,
  Brain,
  MapPin,
  Calendar,
  Search,
  Bookmark,
  Share2,
  ExternalLink,
  Tag,
  Check,
  ChevronRight,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { CurrentAffair } from '../../types';

export const GkCurrentAffairsPage: React.FC = () => {
  const { currentAffairs, toggleBookmark, isBookmarked } = useData();

  const [activeTab, setActiveTab] = useState<'all' | 'national' | 'international' | 'economy' | 'sports' | 'science'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAffair, setSelectedAffair] = useState<CurrentAffair | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredAffairs = useMemo(() => {
    return currentAffairs.filter(item => {
      const matchesTab = activeTab === 'all' || item.category === activeTab;
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        item.title.toLowerCase().includes(query) ||
        (item.nepali_title && item.nepali_title.toLowerCase().includes(query)) ||
        item.summary.toLowerCase().includes(query) ||
        item.details.toLowerCase().includes(query) ||
        item.tags.some(t => t.toLowerCase().includes(query));

      return matchesTab && matchesSearch;
    });
  }, [currentAffairs, activeTab, searchQuery]);

  const handleShare = (id: string) => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-700 mb-2">
            <Flame className="w-3.5 h-3.5" />
            <span>High-Frequency Exam Capsules</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            GK & Current Affairs Capsule
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl font-nepali">
            नेपाल तथा अन्तर्राष्ट्रिय समसामयिक घटनाक्रम, राष्ट्रिय योजना, तथ्याङ्क तथा परीक्षा उपयोगी सामान्य ज्ञान
          </p>
        </div>

        {/* Category Pills & Search */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="w-full md:w-80 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search GK facts, appointments..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-slate-50/50"
              />
            </div>

            {/* Filter Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
              {[
                { id: 'all', label: 'All Affairs' },
                { id: 'national', label: 'Nepal Affairs' },
                { id: 'international', label: 'International & UN' },
                { id: 'economy', label: 'Economy & Budget' },
                { id: 'sports', label: 'Sports & Awards' },
                { id: 'science', label: 'Science & Health' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Feed Column */}
          <div className="lg:col-span-2 space-y-4">
            {filteredAffairs.length === 0 ? (
              <div className="bg-white rounded-xl p-10 text-center border border-slate-200">
                <Globe className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">No capsules match your filter.</p>
                <p className="text-xs text-slate-400 mt-0.5">Try clearing your search query.</p>
              </div>
            ) : (
              filteredAffairs.map(item => {
                const bookmarked = isBookmarked('current_affair', item.id);

                return (
                  <article
                    key={item.id}
                    onClick={() => setSelectedAffair(item)}
                    className="bg-white rounded-xl shadow-xs hover:shadow-md border border-slate-200 hover:border-orange-200 p-5 sm:p-6 transition cursor-pointer group"
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-orange-100 text-orange-700 uppercase">
                          {item.category}
                        </span>
                        <span className="flex items-center gap-1 text-[11px] text-slate-400">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{item.published_date}</span>
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            toggleBookmark('current_affair', item.id);
                          }}
                          className={`p-1.5 rounded-lg hover:bg-slate-100 transition ${
                            bookmarked ? 'text-orange-600' : 'text-slate-400'
                          }`}
                          title="Save bookmark"
                        >
                          <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-orange-600' : ''}`} />
                        </button>

                        <button
                          onClick={e => {
                            e.stopPropagation();
                            handleShare(item.id);
                          }}
                          className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 transition"
                          title="Share"
                        >
                          {copiedId === item.id ? (
                            <Check className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Share2 className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <h2 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-orange-600 transition leading-snug">
                      {item.title}
                    </h2>
                    {item.nepali_title && (
                      <h3 className="text-xs sm:text-sm text-slate-600 font-nepali mt-1">
                        {item.nepali_title}
                      </h3>
                    )}

                    <p className="text-xs sm:text-sm text-slate-600 mt-2.5 leading-relaxed">
                      {item.summary}
                    </p>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap gap-1">
                        {item.tags.map(t => (
                          <span
                            key={t}
                            className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-medium"
                          >
                            #{t}
                          </span>
                        ))}
                      </div>

                      <div className="text-xs font-bold text-orange-600 flex items-center gap-1 group-hover:translate-x-0.5 transition">
                        <span>Read Full Analysis</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </article>
                );
              })
            )}
          </div>

          {/* Sidebar: Nepal Fast Facts & Static GK reference */}
          <div className="space-y-6">
            {/* Census 2078 Cheat Sheet */}
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-orange-600 text-white flex items-center justify-center font-bold text-xs">
                  📊
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Census 2078 Quick Facts
                  </h3>
                  <p className="text-[10px] text-slate-400 font-nepali">राष्ट्रिय जनगणना २०७८</p>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Total Population:</span>
                  <span className="font-bold text-slate-800">29,164,578</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Growth Rate:</span>
                  <span className="font-bold text-slate-800">0.92% per annum</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Literacy Rate:</span>
                  <span className="font-bold text-slate-800">76.2%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Sex Ratio:</span>
                  <span className="font-bold text-slate-800">95.59 (M per 100 F)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Highest Populated:</span>
                  <span className="font-bold text-slate-800">Kathmandu (20.41 Lakh)</span>
                </div>
              </div>
            </div>

            {/* Constitution Key Articles */}
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-blue-900 text-white flex items-center justify-center font-bold text-xs">
                  ⚖️
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Constitution Mnemonic Guide
                  </h3>
                  <p className="text-[10px] text-slate-400 font-nepali">मौलिक हक (धारा १६-४६)</p>
                </div>
              </div>

              <ul className="space-y-1.5 text-xs text-slate-600">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                  <span><strong>Part 3:</strong> 31 Fundamental Rights in total</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                  <span><strong>Article 16:</strong> Right to live with dignity</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                  <span><strong>Article 27:</strong> Right to Information (सूचनाको हक)</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                  <span><strong>Article 30:</strong> Right to clean environment</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                  <span><strong>Part 4:</strong> Directive Principles & State Policies</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedAffair && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
            <div className="bg-slate-900 text-white p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-orange-600 text-white uppercase">
                  {selectedAffair.category}
                </span>
                <button
                  onClick={() => setSelectedAffair(null)}
                  className="text-slate-400 hover:text-white text-sm"
                >
                  ✕
                </button>
              </div>

              <h2 className="text-lg sm:text-xl font-bold leading-snug">
                {selectedAffair.title}
              </h2>
              {selectedAffair.nepali_title && (
                <p className="text-xs sm:text-sm text-slate-300 font-nepali mt-1">
                  {selectedAffair.nepali_title}
                </p>
              )}
            </div>

            <div className="p-6 space-y-4">
              <div className="flex items-center gap-4 text-xs text-slate-500 border-b border-slate-100 pb-3">
                <span>Date: {selectedAffair.published_date}</span>
                {selectedAffair.source && <span>Source: {selectedAffair.source}</span>}
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Executive Summary
                </h4>
                <p className="text-sm text-slate-700 leading-relaxed">
                  {selectedAffair.summary}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Detailed Exam Analysis & Insights
                </h4>
                <p className="text-sm text-slate-700 leading-relaxed">
                  {selectedAffair.details}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end">
                <button
                  onClick={() => setSelectedAffair(null)}
                  className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800"
                >
                  Close Capsule
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

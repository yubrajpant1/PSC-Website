import React from 'react';
import {
  HardHat,
  MapPin,
  BookOpen,
  Brain,
  Flame,
  Globe,
  ArrowRight,
  FileText,
  CheckSquare,
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { SubjectCategory } from '../../types';

interface CategoryGridProps {
  onSelectCategory: (category: SubjectCategory) => void;
}

export const CategoryGrid: React.FC<CategoryGridProps> = ({ onSelectCategory }) => {
  const { subjects, materials, questions } = useData();

  const iconMap: Record<string, React.ReactNode> = {
    HardHat: <HardHat className="w-6 h-6 text-orange-600" />,
    MapPin: <MapPin className="w-6 h-6 text-emerald-600" />,
    BookOpen: <BookOpen className="w-6 h-6 text-blue-600" />,
    Brain: <Brain className="w-6 h-6 text-purple-600" />,
    Flame: <Flame className="w-6 h-6 text-rose-600" />,
    Globe: <Globe className="w-6 h-6 text-cyan-600" />,
  };

  return (
    <section className="py-12 sm:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-xs font-bold text-orange-600 uppercase tracking-widest mb-1.5">
            Structured Syllabus Tracks
          </h2>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Study Resource Categories
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 font-nepali mt-1">
            नेपाल लोकसेवा आयोगको पाठ्यक्रम बमोजिम विषयगत सामग्रीहरू
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map(subject => {
            const subjectNotes = materials.filter(m => m.category === subject.category).length;
            const subjectQs = questions.filter(q => q.category === subject.category).length;

            return (
              <div
                key={subject.id}
                onClick={() => onSelectCategory(subject.category)}
                className="group p-6 rounded-2xl border border-slate-200 hover:border-orange-400 bg-white hover:bg-orange-50/10 shadow-xs hover:shadow-lg transition-all duration-200 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                      {iconMap[subject.icon_name] || <BookOpen className="w-6 h-6 text-orange-600" />}
                    </div>

                    <div className="flex items-center gap-2 text-slate-500 text-xs font-medium">
                      <span className="flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5 text-slate-400" />
                        <span>{subjectNotes} Notes</span>
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <CheckSquare className="w-3.5 h-3.5 text-slate-400" />
                        <span>{subjectQs} MCQs</span>
                      </span>
                    </div>
                  </div>

                  <h4 className="text-base font-bold text-slate-900 group-hover:text-orange-600 transition">
                    {subject.name}
                  </h4>
                  <p className="text-xs text-slate-500 font-nepali mt-0.5">
                    {subject.nepali_name}
                  </p>
                  <p className="text-xs text-slate-600 mt-2.5 line-clamp-3 leading-relaxed">
                    {subject.description}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-orange-600 group-hover:translate-x-1 transition-transform">
                  <span>Explore Syllabus Notes</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

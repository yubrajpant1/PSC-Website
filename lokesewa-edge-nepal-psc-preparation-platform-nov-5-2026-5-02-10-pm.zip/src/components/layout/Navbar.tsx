import React, { useState } from 'react';
import {
  Menu,
  X,
  BookOpen,
  CheckSquare,
  Globe,
  Bell,
  User,
  Shield,
  LogOut,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { Logo } from '../common/Logo';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string, filterParams?: any) => void;
  onOpenAuth: (tab?: 'login' | 'signup') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenAuth,
}) => {
  const { user, isAdmin, logout, switchDemoRole } = useAuth();
  const { notices } = useData();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  // Active notices count
  const activeVacancies = notices.filter(n => n.type === 'vacancy' && n.is_active).length;

  const handleNav = (view: string, params?: any) => {
    onNavigate(view, params);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top Notification Announcement Bar */}
      <div className="bg-slate-900 text-white text-[12px] py-1.5 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wide shrink-0">
              New Notice
            </span>
            <span className="text-slate-300 truncate">
              Public Service Commission: 5th Level Sub-Engineer & Nayab Subba Examination Updates published!
            </span>
          </div>

          <div className="flex items-center gap-4 shrink-0 text-slate-300">
            {/* Quick Role Switcher for Evaluators / Testing */}
            <div className="hidden md:flex items-center gap-1.5 text-[11px] bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
              <span className="text-slate-400">Mode:</span>
              <button
                onClick={() => switchDemoRole('student')}
                className={`px-1.5 py-0.5 rounded cursor-pointer transition ${
                  !isAdmin ? 'bg-orange-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Student
              </button>
              <span className="text-slate-600">|</span>
              <button
                onClick={() => switchDemoRole('admin')}
                className={`px-1.5 py-0.5 rounded cursor-pointer transition ${
                  isAdmin ? 'bg-orange-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Admin
              </button>
            </div>

            <span className="hidden sm:inline-block text-slate-400">|</span>
            <span className="hidden sm:inline-block font-nepali">लोकसेवा आयोग तयारी मञ्च</span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            onClick={() => handleNav('home')}
            className="cursor-pointer py-1"
          >
            <Logo size="md" />
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              onClick={() => handleNav('home')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition ${
                currentView === 'home'
                  ? 'text-orange-600 bg-orange-50/70'
                  : 'text-slate-700 hover:text-orange-600 hover:bg-slate-50'
              }`}
            >
              Home
            </button>

            <button
              onClick={() => handleNav('materials')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition ${
                currentView === 'materials'
                  ? 'text-orange-600 bg-orange-50/70'
                  : 'text-slate-700 hover:text-orange-600 hover:bg-slate-50'
              }`}
            >
              <BookOpen className="w-4 h-4 text-slate-400" />
              <span>Study Notes & PDFs</span>
            </button>

            <button
              onClick={() => handleNav('mcq')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition ${
                currentView === 'mcq'
                  ? 'text-orange-600 bg-orange-50/70'
                  : 'text-slate-700 hover:text-orange-600 hover:bg-slate-50'
              }`}
            >
              <CheckSquare className="w-4 h-4 text-slate-400" />
              <span>MCQ Practice</span>
              <span className="px-1.5 py-0.2 text-[10px] bg-orange-100 text-orange-700 font-bold rounded">
                Test Mode
              </span>
            </button>

            <button
              onClick={() => handleNav('gk')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition ${
                currentView === 'gk'
                  ? 'text-orange-600 bg-orange-50/70'
                  : 'text-slate-700 hover:text-orange-600 hover:bg-slate-50'
              }`}
            >
              <Globe className="w-4 h-4 text-slate-400" />
              <span>GK & Current Affairs</span>
            </button>

            <button
              onClick={() => handleNav('notices')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition ${
                currentView === 'notices'
                  ? 'text-orange-600 bg-orange-50/70'
                  : 'text-slate-700 hover:text-orange-600 hover:bg-slate-50'
              }`}
            >
              <Bell className="w-4 h-4 text-slate-400" />
              <span>PSC Notices</span>
              {activeVacancies > 0 && (
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              )}
            </button>
          </nav>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            {/* Admin Portal Button (always visible if admin) */}
            {isAdmin && (
              <button
                onClick={() => handleNav('admin')}
                className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs cursor-pointer ${
                  currentView === 'admin'
                    ? 'bg-slate-900 text-orange-400 ring-2 ring-orange-500'
                    : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                <Shield className="w-3.5 h-3.5 text-orange-400" />
                <span>Admin Dashboard</span>
              </button>
            )}

            {/* Auth Buttons / User Profile */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 py-1.5 px-2.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-white text-slate-800 transition cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-orange-600 to-amber-500 text-white font-bold text-xs flex items-center justify-center">
                    {user.full_name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                  <div className="hidden sm:block text-left">
                    <p className="text-xs font-bold text-slate-800 leading-none truncate max-w-[110px]">
                      {user.full_name || 'Student'}
                    </p>
                    <p className="text-[10px] text-slate-500 leading-none mt-0.5 capitalize">
                      {user.role}
                    </p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div
                    className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-100 py-1.5 z-50 animate-fade-in"
                    onMouseLeave={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-3 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-800 truncate">{user.full_name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                      {user.target_exam && (
                        <p className="text-[10px] text-orange-600 font-medium mt-1 truncate">
                          🎯 {user.target_exam}
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        handleNav('dashboard');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-orange-50 hover:text-orange-600 flex items-center gap-2"
                    >
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>Student Dashboard</span>
                    </button>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          handleNav('admin');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-orange-50 hover:text-orange-600 flex items-center gap-2"
                      >
                        <Shield className="w-3.5 h-3.5 text-orange-500" />
                        <span>Admin Control Panel</span>
                      </button>
                    )}

                    <div className="border-t border-slate-100 my-1"></div>

                    <button
                      onClick={() => {
                        logout();
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5 text-red-500" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-orange-600 transition cursor-pointer"
                >
                  Sign In
                </button>
                <button
                  onClick={() => onOpenAuth('signup')}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-xs transition flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Get Started</span>
                </button>
              </div>
            )}

            {/* Mobile menu hamburger button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-1 shadow-lg">
          <button
            onClick={() => handleNav('home')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
              currentView === 'home' ? 'text-orange-600 bg-orange-50' : 'text-slate-700'
            }`}
          >
            Home
          </button>

          <button
            onClick={() => handleNav('materials')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold ${
              currentView === 'materials' ? 'text-orange-600 bg-orange-50' : 'text-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-slate-400" />
              Study Notes & PDFs
            </span>
          </button>

          <button
            onClick={() => handleNav('mcq')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold ${
              currentView === 'mcq' ? 'text-orange-600 bg-orange-50' : 'text-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-slate-400" />
              MCQ Practice & Tests
            </span>
            <span className="text-[10px] bg-orange-100 text-orange-700 font-bold px-2 py-0.5 rounded">
              Timed Mode
            </span>
          </button>

          <button
            onClick={() => handleNav('gk')}
            className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-semibold ${
              currentView === 'gk' ? 'text-orange-600 bg-orange-50' : 'text-slate-700'
            }`}
          >
            <Globe className="w-4 h-4 text-slate-400" />
            GK & Current Affairs
          </button>

          <button
            onClick={() => handleNav('notices')}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold ${
              currentView === 'notices' ? 'text-orange-600 bg-orange-50' : 'text-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-slate-400" />
              PSC Notices & Routine
            </span>
            {activeVacancies > 0 && (
              <span className="text-xs bg-red-100 text-red-600 font-bold px-2 py-0.5 rounded-full">
                {activeVacancies} Active
              </span>
            )}
          </button>

          {user && (
            <button
              onClick={() => handleNav('dashboard')}
              className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-semibold ${
                currentView === 'dashboard' ? 'text-orange-600 bg-orange-50' : 'text-slate-700'
              }`}
            >
              <User className="w-4 h-4 text-slate-400" />
              Student Dashboard
            </button>
          )}

          {isAdmin && (
            <button
              onClick={() => handleNav('admin')}
              className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-bold bg-slate-900 text-orange-400`}
            >
              <Shield className="w-4 h-4 text-orange-400" />
              Admin Dashboard
            </button>
          )}

          {/* Quick Demo switcher for mobile */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Demo Mode:</span>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  switchDemoRole('student');
                  setMobileMenuOpen(false);
                }}
                className="px-2 py-1 rounded bg-slate-100 text-slate-700 font-medium"
              >
                Student
              </button>
              <button
                onClick={() => {
                  switchDemoRole('admin');
                  setMobileMenuOpen(false);
                }}
                className="px-2 py-1 rounded bg-slate-800 text-white font-medium"
              >
                Admin
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

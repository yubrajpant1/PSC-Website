import React, { useState, useEffect, useMemo } from 'react';
import {
  CheckSquare,
  Clock,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  Sparkles,
  BookOpen,
  Filter,
  Layers,
  Award,
  AlertTriangle,
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { McqQuestion, SubjectCategory, QuizAttempt } from '../../types';
import { QuizResults } from './QuizResults';

interface McqPracticePageProps {
  onNavigateToNotes?: () => void;
}

export const McqPracticePage: React.FC<McqPracticePageProps> = ({
  onNavigateToNotes,
}) => {
  const { questions, subjects, saveQuizAttempt } = useData();
  const { user } = useAuth();

  // Settings & Filter
  const [selectedCategory, setSelectedCategory] = useState<SubjectCategory | 'all'>('all');
  const [examMode, setExamMode] = useState<'practice' | 'timed'>('practice');
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);

  // Filtered Questions for Quiz
  const activeQuizQuestions = useMemo(() => {
    if (selectedCategory === 'all') return questions;
    return questions.filter(q => q.category === selectedCategory);
  }, [questions, selectedCategory]);

  // Quiz Execution States
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({}); // question_id -> option_id
  const [showExplanation, setShowExplanation] = useState<Record<string, boolean>>({});
  const [timeRemaining, setTimeRemaining] = useState(45 * 60); // 45 minutes default
  const [elapsedTime, setElapsedTime] = useState(0);
  const [lastAttempt, setLastAttempt] = useState<QuizAttempt | null>(null);

  // Timer for Timed Exam
  useEffect(() => {
    let timer: any;
    if (quizStarted && !quizCompleted) {
      timer = setInterval(() => {
        setElapsedTime(prev => prev + 1);
        if (examMode === 'timed') {
          setTimeRemaining(prev => {
            if (prev <= 1) {
              clearInterval(timer);
              handleSubmitQuiz();
              return 0;
            }
            return prev - 1;
          });
        }
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [quizStarted, quizCompleted, examMode]);

  const currentQ = activeQuizQuestions[currentIndex];

  const handleSelectOption = (questionId: string, optionId: string) => {
    if (quizCompleted) return;

    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionId,
    }));

    // In practice mode, automatically reveal explanation once an answer is chosen
    if (examMode === 'practice') {
      setShowExplanation(prev => ({
        ...prev,
        [questionId]: true,
      }));
    }
  };

  const handleNext = () => {
    if (currentIndex < activeQuizQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const handleSubmitQuiz = async () => {
    let correctCount = 0;
    let incorrectCount = 0;
    let unansweredCount = 0;

    const answersBreakdown = activeQuizQuestions.map(q => {
      const selectedId = selectedAnswers[q.id];
      const correctOpt = q.options.find(o => o.is_correct);
      const isCorrect = selectedId === correctOpt?.id;

      if (!selectedId) {
        unansweredCount++;
      } else if (isCorrect) {
        correctCount++;
      } else {
        incorrectCount++;
      }

      return {
        question_id: q.id,
        selected_option_id: selectedId || '',
        is_correct: isCorrect,
      };
    });

    // Score percentage: Loksewa standard allows negative marking (-0.20 per wrong answer)
    // For general practice percentage:
    const rawScore = examMode === 'timed'
      ? Math.max(0, correctCount * 1 - incorrectCount * 0.2)
      : correctCount;
    
    const percentage = Math.round((rawScore / activeQuizQuestions.length) * 100);

    const subjectObj = subjects.find(s => s.category === selectedCategory);
    const subjectTitle = selectedCategory === 'all' ? 'All PSC Combined Subjects' : (subjectObj?.name || 'PSC Practice');

    const attempt = await saveQuizAttempt({
      user_id: user?.id || 'guest',
      user_name: user?.full_name || 'Guest Aspirant',
      subject_id: selectedCategory,
      subject_name: subjectTitle,
      total_questions: activeQuizQuestions.length,
      correct_count: correctCount,
      incorrect_count: incorrectCount,
      unanswered_count: unansweredCount,
      score_percentage: percentage,
      time_spent_seconds: elapsedTime,
      answers: answersBreakdown,
    });

    setLastAttempt(attempt);
    setQuizCompleted(true);
  };

  const handleStartQuiz = () => {
    if (activeQuizQuestions.length === 0) return;
    setCurrentIndex(0);
    setSelectedAnswers({});
    setShowExplanation({});
    setElapsedTime(0);
    setTimeRemaining(activeQuizQuestions.length * 60); // 1 min per question
    setQuizStarted(true);
    setQuizCompleted(false);
  };

  const handleRestart = () => {
    handleStartQuiz();
  };

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  // If completed, show final scorecard
  if (quizCompleted && lastAttempt) {
    return (
      <div className="min-h-screen bg-slate-50 py-8">
        <QuizResults
          attempt={lastAttempt}
          questions={activeQuizQuestions}
          onRestart={handleRestart}
          onExploreNotes={onNavigateToNotes || (() => {})}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 sm:py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Quiz Setup Screen if not yet started */}
        {!quizStarted ? (
          <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="bg-slate-900 p-6 sm:p-8 text-white text-center">
              <div className="w-14 h-14 rounded-2xl bg-orange-600 mx-auto flex items-center justify-center mb-4 shadow-lg shadow-orange-600/30">
                <CheckSquare className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Loksewa MCQ Practice & Mock Test
              </h1>
              <p className="text-sm text-slate-300 font-nepali mt-2">
                लोकसेवा आयोगको ढाँचामा आधारित वस्तुगत बहुवैकल्पिक परीक्षा अभ्यास
              </p>
            </div>

            <div className="p-6 sm:p-8 space-y-6">
              {/* Category Picker */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Select Question Category (विषय छनोट)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className={`p-3 rounded-xl border text-left text-xs font-semibold transition cursor-pointer flex items-center justify-between ${
                      selectedCategory === 'all'
                        ? 'border-orange-600 bg-orange-50 text-orange-900 ring-1 ring-orange-600'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                    }`}
                  >
                    <span>All Subjects Combined</span>
                    <span className="text-[11px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                      {questions.length} Qs
                    </span>
                  </button>

                  {subjects.map(s => {
                    const qCount = questions.filter(q => q.category === s.category).length;
                    return (
                      <button
                        key={s.id}
                        onClick={() => setSelectedCategory(s.category)}
                        className={`p-3 rounded-xl border text-left text-xs font-semibold transition cursor-pointer flex items-center justify-between ${
                          selectedCategory === s.category
                            ? 'border-orange-600 bg-orange-50 text-orange-900 ring-1 ring-orange-600'
                            : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                        }`}
                      >
                        <div className="truncate pr-2">
                          <p className="truncate">{s.name}</p>
                          <p className="text-[10px] text-slate-400 font-nepali truncate">{s.nepali_name}</p>
                        </div>
                        <span className="text-[11px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                          {qCount} Qs
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Mode Toggle */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Choose Practice Mode
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setExamMode('practice')}
                    className={`p-4 rounded-xl border cursor-pointer transition ${
                      examMode === 'practice'
                        ? 'border-orange-600 bg-orange-50/50 ring-1 ring-orange-600'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Sparkles className="w-4 h-4 text-orange-600" />
                      <h4 className="text-sm font-bold text-slate-900">Learning Practice Mode</h4>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Instant feedback after selecting each question with in-depth Nepali & English explanations. No rush.
                    </p>
                  </div>

                  <div
                    onClick={() => setExamMode('timed')}
                    className={`p-4 rounded-xl border cursor-pointer transition ${
                      examMode === 'timed'
                        ? 'border-orange-600 bg-orange-50/50 ring-1 ring-orange-600'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="w-4 h-4 text-orange-600" />
                      <h4 className="text-sm font-bold text-slate-900">Simulated PSC Timed Exam</h4>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Real exam pressure with countdown timer, question palette, and Loksewa negative marking (-20%).
                    </p>
                  </div>
                </div>
              </div>

              {/* Notice pill */}
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  All questions are reviewed against the standard PSC curriculum. Questions support both English and official Nepali Devanagari script.
                </span>
              </div>

              {/* Start Test Button */}
              <button
                onClick={handleStartQuiz}
                disabled={activeQuizQuestions.length === 0}
                className="w-full py-3 px-6 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-md shadow-orange-600/20 text-sm flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
              >
                <span>Start Practice ({activeQuizQuestions.length} Questions)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Active Quiz Interactive Session */
          <div className="space-y-6">
            {/* Quiz Header Bar */}
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuizStarted(false)}
                  className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 text-xs font-semibold flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Exit Test</span>
                </button>

                <div className="text-xs">
                  <span className="font-bold text-slate-900">
                    Question {currentIndex + 1} of {activeQuizQuestions.length}
                  </span>
                  <span className="text-slate-400 mx-1.5">•</span>
                  <span className="text-slate-500">{currentQ?.subject_name}</span>
                </div>
              </div>

              {/* Timer & Submit */}
              <div className="flex items-center gap-3">
                {examMode === 'timed' ? (
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-red-50 text-red-700 rounded-lg text-xs font-mono font-bold border border-red-200">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{formatTimer(timeRemaining)}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-mono font-medium">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{formatTimer(elapsedTime)}</span>
                  </div>
                )}

                <button
                  onClick={handleSubmitQuiz}
                  className="py-1.5 px-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  Submit Exam
                </button>
              </div>
            </div>

            {/* Question Progress Bar */}
            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-orange-600 h-full transition-all duration-300"
                style={{
                  width: `${((currentIndex + 1) / activeQuizQuestions.length) * 100}%`,
                }}
              />
            </div>

            {/* Question Card */}
            {currentQ && (
              <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-6 sm:p-8">
                {/* Meta details */}
                <div className="flex items-center justify-between gap-2 mb-4">
                  <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-orange-100 text-orange-800">
                    {currentQ.topic}
                  </span>

                  <span className="text-xs text-slate-400 capitalize">
                    Difficulty: <strong className="text-slate-700">{currentQ.difficulty}</strong>
                  </span>
                </div>

                {/* Question Statement */}
                <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                  {currentQ.question_text}
                </h2>
                {currentQ.question_text_nepali && (
                  <p className="text-sm sm:text-base text-slate-700 font-nepali mt-2 font-medium">
                    {currentQ.question_text_nepali}
                  </p>
                )}

                {/* 4 Options Grid */}
                <div className="mt-6 space-y-3">
                  {currentQ.options.map((option, optIdx) => {
                    const letter = String.fromCharCode(65 + optIdx);
                    const isSelected = selectedAnswers[currentQ.id] === option.id;
                    const isPracticeSubmitted = examMode === 'practice' && isSelected;
                    const isCorrectAnswer = option.is_correct;

                    let optionBorder = 'border-slate-200 bg-white hover:border-orange-300 hover:bg-slate-50/50';
                    let badgeColor = 'bg-slate-100 text-slate-700';

                    if (isSelected) {
                      optionBorder = 'border-orange-600 bg-orange-50/50 ring-1 ring-orange-600';
                      badgeColor = 'bg-orange-600 text-white';
                    }

                    // In practice mode, highlight correct and incorrect immediately after answer
                    if (examMode === 'practice' && selectedAnswers[currentQ.id]) {
                      if (isCorrectAnswer) {
                        optionBorder = 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500';
                        badgeColor = 'bg-emerald-600 text-white';
                      } else if (isSelected && !isCorrectAnswer) {
                        optionBorder = 'border-rose-500 bg-rose-50/60 ring-1 ring-rose-500';
                        badgeColor = 'bg-rose-600 text-white';
                      }
                    }

                    return (
                      <div
                        key={option.id}
                        onClick={() => handleSelectOption(currentQ.id, option.id)}
                        className={`p-4 rounded-xl border cursor-pointer transition flex items-start gap-3.5 ${optionBorder}`}
                      >
                        <span
                          className={`w-6 h-6 rounded-md font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 ${badgeColor}`}
                        >
                          {letter}
                        </span>

                        <div className="flex-1">
                          <p className="text-sm font-semibold text-slate-800">
                            {option.text}
                          </p>
                          {option.text_nepali && (
                            <p className="text-xs text-slate-600 font-nepali mt-0.5">
                              {option.text_nepali}
                            </p>
                          )}
                        </div>

                        {examMode === 'practice' && selectedAnswers[currentQ.id] && (
                          <div className="shrink-0 mt-0.5">
                            {isCorrectAnswer && (
                              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                            )}
                            {isSelected && !isCorrectAnswer && (
                              <XCircle className="w-5 h-5 text-rose-600" />
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Practice Mode Explanation Box */}
                {examMode === 'practice' && selectedAnswers[currentQ.id] && (
                  <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-200 animate-fade-in">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-orange-600 uppercase tracking-wider mb-1.5">
                      <HelpCircle className="w-4 h-4" />
                      <span>Verified PSC Answer & Explanation</span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                      {currentQ.explanation}
                    </p>
                    {currentQ.explanation_nepali && (
                      <p className="text-xs sm:text-sm text-slate-600 font-nepali mt-2 leading-relaxed">
                        {currentQ.explanation_nepali}
                      </p>
                    )}
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={handlePrev}
                    disabled={currentIndex === 0}
                    className="py-2 px-4 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 transition"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Previous</span>
                  </button>

                  <div className="text-xs text-slate-400">
                    Answered {Object.keys(selectedAnswers).length} of {activeQuizQuestions.length}
                  </div>

                  {currentIndex < activeQuizQuestions.length - 1 ? (
                    <button
                      onClick={handleNext}
                      className="py-2 px-4 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                    >
                      <span>Next Question</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <button
                      onClick={handleSubmitQuiz}
                      className="py-2 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                    >
                      <span>Complete & View Score</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Question Quick Jump Palette */}
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2.5">
                Question Palette
              </span>
              <div className="flex flex-wrap gap-2">
                {activeQuizQuestions.map((q, qIndex) => {
                  const isAnswered = Boolean(selectedAnswers[q.id]);
                  const isActive = qIndex === currentIndex;

                  let btnStyle = 'bg-slate-100 text-slate-700 border-slate-200';
                  if (isAnswered) {
                    btnStyle = 'bg-orange-600 text-white border-orange-600 font-bold';
                  }
                  if (isActive) {
                    btnStyle = 'ring-2 ring-slate-900 border-slate-900 font-bold';
                  }

                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentIndex(qIndex)}
                      className={`w-8 h-8 rounded-lg text-xs font-medium border flex items-center justify-center transition cursor-pointer ${btnStyle}`}
                    >
                      {qIndex + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

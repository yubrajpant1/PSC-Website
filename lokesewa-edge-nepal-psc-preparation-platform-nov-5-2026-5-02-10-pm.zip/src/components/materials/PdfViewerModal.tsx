import React, { useState } from 'react';
import {
  X,
  Download,
  Bookmark,
  Share2,
  FileText,
  Calendar,
  User,
  Layers,
  BookOpen,
  Check,
  ExternalLink,
} from 'lucide-react';
import { StudyMaterial } from '../../types';
import { useData } from '../../context/DataContext';

interface PdfViewerModalProps {
  material: StudyMaterial | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  material,
  isOpen,
  onClose,
}) => {
  const { incrementDownload, toggleBookmark, isBookmarked } = useData();
  const [activeTab, setActiveTab] = useState<'preview' | 'syllabus'>('preview');
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen || !material) return null;

  const bookmarked = isBookmarked('material', material.id);

  const handleDownload = () => {
    incrementDownload(material.id);
    // Trigger download in new window or simulate download
    const link = document.createElement('a');
    link.href = material.file_url;
    link.target = '_blank';
    link.download = `${material.title.replace(/\s+/g, '_')}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/70 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-4xl h-[90vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-start justify-between border-b border-slate-800">
          <div className="pr-6">
            <div className="flex flex-wrap items-center gap-2 mb-1.5">
              <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-orange-600 text-white">
                {material.level}
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                {material.subject_name}
              </span>
              {material.is_featured && (
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-400 text-slate-900">
                  ★ High Yield
                </span>
              )}
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white leading-snug">
              {material.title}
            </h3>
            {material.nepali_title && (
              <p className="text-xs sm:text-sm text-slate-300 font-nepali mt-0.5">
                {material.nepali_title}
              </p>
            )}
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar & Metadata Bar */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span>{material.author}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>{material.created_at}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>{material.page_count} Pages ({material.file_size})</span>
            </span>
            <span className="flex items-center gap-1.5 text-orange-600 font-medium">
              <Download className="w-3.5 h-3.5" />
              <span>{material.downloads_count} Downloads</span>
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleBookmark('material', material.id)}
              className={`p-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                bookmarked
                  ? 'bg-orange-50 border-orange-300 text-orange-600'
                  : 'bg-white border-slate-300 hover:bg-slate-100 text-slate-700'
              }`}
              title={bookmarked ? 'Saved to bookmarks' : 'Save to bookmarks'}
            >
              <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-orange-600' : ''}`} />
              <span className="hidden sm:inline">{bookmarked ? 'Saved' : 'Save'}</span>
            </button>

            <button
              onClick={handleShare}
              className="p-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              title="Share"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copiedLink ? 'Copied' : 'Share'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>
          </div>
        </div>

        {/* View mode switcher */}
        <div className="flex border-b border-slate-200 bg-white px-6">
          <button
            onClick={() => setActiveTab('preview')}
            className={`py-2 px-3 text-xs font-bold border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'preview'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Interactive Reader & Document</span>
          </button>
          <button
            onClick={() => setActiveTab('syllabus')}
            className={`py-2 px-3 text-xs font-bold border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'syllabus'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Syllabus & High-Yield Summary</span>
          </button>
        </div>

        {/* Modal Main Content Container */}
        <div className="flex-1 bg-slate-100 overflow-y-auto p-4 sm:p-6">
          {activeTab === 'preview' ? (
            <div className="max-w-3xl mx-auto space-y-6">
              {/* Document Overview Card */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-6">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-orange-600 mb-1">
                      Document Synopsis & Exam Focus
                    </h4>
                    <p className="text-slate-700 text-sm leading-relaxed">
                      {material.description}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap gap-1.5">
                  {material.tags.map(t => (
                    <span
                      key={t}
                      className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[11px] font-medium"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Embedded Document Reader / PDF Preview */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="bg-slate-800 text-slate-200 px-4 py-2 text-xs flex items-center justify-between">
                  <span className="font-mono text-[11px]">Preview: {material.title.slice(0, 40)}...pdf</span>
                  <a
                    href={material.file_url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 hover:text-white text-orange-400"
                  >
                    <span>Open External PDF</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* PDF Reader Canvas / Mock Frame */}
                <div className="p-8 sm:p-12 bg-white text-slate-800 font-serif min-h-[400px]">
                  <div className="max-w-2xl mx-auto border-b-2 border-slate-800 pb-4 mb-6 text-center">
                    <span className="text-xs uppercase tracking-widest text-slate-500 font-sans font-bold">
                      LOKESEWA EDGE • PSC STUDY CAPSULE
                    </span>
                    <h1 className="text-xl sm:text-2xl font-bold font-sans text-slate-900 mt-2">
                      {material.title}
                    </h1>
                    {material.nepali_title && (
                      <h2 className="text-base text-slate-700 font-nepali mt-1 font-semibold">
                        {material.nepali_title}
                      </h2>
                    )}
                    <div className="mt-3 text-xs text-slate-500 font-sans flex items-center justify-center gap-3">
                      <span>Subject: {material.subject_name}</span>
                      <span>•</span>
                      <span>Level: {material.level}</span>
                    </div>
                  </div>

                  <div className="space-y-4 text-sm leading-relaxed text-slate-700">
                    <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs font-sans text-amber-900">
                      <strong>📌 Examination Notice:</strong> This material is prepared according to the latest revised syllabus of Nepal Public Service Commission (लोक सेवा आयोग). Recommended for objective MCQs and subjective paper prep.
                    </div>

                    <h3 className="font-sans font-bold text-slate-900 text-base mt-4">
                      Chapter 1: Essential Fundamental Principles
                    </h3>
                    <p>
                      {material.description}
                    </p>
                    <p>
                      All formulas, standards, and constitutional provisions cited in this note adhere strictly to Nepal Standards, Nepal Civil Service Regulations, and standard engineering specifications.
                    </p>

                    <div className="border border-slate-200 rounded-lg p-4 bg-slate-50 text-xs font-sans space-y-2">
                      <p className="font-bold text-slate-800">Key High-Yield Exam Takeaways:</p>
                      <ul className="list-disc pl-5 space-y-1 text-slate-700">
                        <li>Directly aligned with PSC past question frequency.</li>
                        <li>Includes verified numerical tables and memory shortcuts.</li>
                        <li>Reviewed by experienced Loksewa officers and engineering toppers.</li>
                      </ul>
                    </div>
                  </div>

                  <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between font-sans text-xs text-slate-500">
                    <span>Page 1 of {material.page_count}</span>
                    <button
                      onClick={handleDownload}
                      className="text-orange-600 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download Full {material.file_size} PDF
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-xs border border-slate-200 p-6 space-y-4">
              <h4 className="font-bold text-slate-900 text-sm">PSC Exam Syllabus Alignment</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                This study note directly maps to the following sections of the official Public Service Commission curriculum:
              </p>

              <div className="space-y-3">
                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <span className="text-xs font-bold text-orange-600 uppercase">Unit 1 • Core Theory & Specifications</span>
                  <p className="text-xs text-slate-700 mt-1">
                    Fundamental concepts, standard units, definitions, classification criteria, and relevant Acts & Rules.
                  </p>
                </div>

                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <span className="text-xs font-bold text-orange-600 uppercase">Unit 2 • Numerical Practice & Formula Application</span>
                  <p className="text-xs text-slate-700 mt-1">
                    Step-by-step solved numericals from past 5 years of Federal and Provincial PSC examinations.
                  </p>
                </div>

                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <span className="text-xs font-bold text-orange-600 uppercase">Unit 3 • Objective MCQ Review</span>
                  <p className="text-xs text-slate-700 mt-1">
                    100+ high-frequency multiple-choice questions with answer key and detailed explanations.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

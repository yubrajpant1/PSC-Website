import React from 'react';

interface LogoProps {
  className?: string;
  showTagline?: boolean;
  size?: 'sm' | 'md' | 'lg';
  light?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  showTagline = true,
  size = 'md',
  light = false,
}) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  };

  const titleSizes = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl md:text-3xl',
  };

  const taglineSizes = {
    sm: 'text-[10px]',
    md: 'text-xs',
    lg: 'text-sm',
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Brand Icon: Book + Modern Edge Shield */}
      <div
        className={`${iconSizes[size]} relative flex items-center justify-center rounded-xl shadow-md transition-transform duration-200 hover:scale-105 ${
          light
            ? 'bg-white/10 ring-1 ring-white/20'
            : 'bg-gradient-to-br from-slate-900 to-navy-900 bg-slate-900 ring-1 ring-slate-800'
        }`}
      >
        <svg
          viewBox="0 0 40 40"
          className="w-3/4 h-3/4"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Outer Crest */}
          <path
            d="M20 4L34 10V22C34 30.5 28 36 20 38C12 36 6 30.5 6 22V10L20 4Z"
            stroke="#ea580c"
            strokeWidth="2.5"
            strokeLinejoin="round"
            fill={light ? '#0f2549' : '#0a192f'}
          />
          {/* Open Book Wings */}
          <path
            d="M13 22C15.5 20.5 18 20.5 20 22C22 20.5 24.5 20.5 27 22"
            stroke="#ffffff"
            strokeWidth="2"
            strokeLinecap="round"
          />
          {/* Upward Edge Arrow / Compass needle */}
          <path
            d="M20 12L20 28"
            stroke="#f97316"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <path
            d="M16 16L20 12L24 16"
            stroke="#f97316"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>

      {/* Typography */}
      <div className="flex flex-col">
        <div className={`font-extrabold tracking-tight leading-none ${titleSizes[size]}`}>
          <span className={light ? 'text-white' : 'text-slate-900'}>Lokesewa</span>
          <span className="text-orange-600 ml-1">Edge</span>
        </div>
        {showTagline && (
          <span
            className={`font-medium tracking-wide mt-0.5 leading-none ${taglineSizes[size]} ${
              light ? 'text-slate-300' : 'text-slate-500'
            }`}
          >
            Prepare Smart. Achieve More.
          </span>
        )}
      </div>
    </div>
  );
};

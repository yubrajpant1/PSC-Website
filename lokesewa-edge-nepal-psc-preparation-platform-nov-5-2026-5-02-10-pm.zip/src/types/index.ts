export type UserRole = 'student' | 'admin';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  target_exam?: string; // e.g., 'Civil Engineering 5th Level', 'Nayab Subba', 'Section Officer'
  phone?: string;
  avatar_url?: string;
  created_at: string;
}

export type SubjectCategory =
  | 'civil_engineering'
  | 'nepal_gk'
  | 'world_gk'
  | 'iq_reasoning'
  | 'current_affairs'
  | 'governance_law'
  | 'kharidar_subba'
  | 'section_officer';

export interface Subject {
  id: string;
  name: string;
  nepali_name: string;
  category: SubjectCategory;
  description: string;
  icon_name: string;
  total_notes: number;
  total_questions: number;
}

export interface StudyMaterial {
  id: string;
  title: string;
  nepali_title?: string;
  subject_id: string;
  subject_name: string;
  category: SubjectCategory;
  level: string; // '4th Level' | '5th Level' | '7th Level' | 'Officer' | 'All Levels'
  description: string;
  file_url: string;
  file_size: string;
  page_count: number;
  downloads_count: number;
  author: string;
  created_at: string;
  is_featured?: boolean;
  tags: string[];
}

export interface McqOption {
  id: string;
  text: string;
  text_nepali?: string;
  is_correct: boolean;
}

export interface McqQuestion {
  id: string;
  subject_id: string;
  subject_name: string;
  category: SubjectCategory;
  topic: string;
  level: string;
  question_text: string;
  question_text_nepali?: string;
  options: McqOption[];
  explanation: string;
  explanation_nepali?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  created_at: string;
}

export interface QuizAttempt {
  id: string;
  user_id: string;
  user_name?: string;
  subject_id: string;
  subject_name: string;
  total_questions: number;
  correct_count: number;
  incorrect_count: number;
  unanswered_count: number;
  score_percentage: number;
  time_spent_seconds: number;
  attempted_at: string;
  answers: {
    question_id: string;
    selected_option_id: string;
    is_correct: boolean;
  }[];
}

export type NoticeType = 'vacancy' | 'exam_routine' | 'result' | 'admit_card' | 'syllabus_update' | 'general';

export interface Notice {
  id: string;
  title: string;
  nepali_title?: string;
  type: NoticeType;
  published_date: string;
  deadline_date?: string;
  description: string;
  pdf_url?: string;
  external_link?: string;
  is_active: boolean;
  is_urgent?: boolean;
}

export interface CurrentAffair {
  id: string;
  title: string;
  nepali_title?: string;
  category: 'national' | 'international' | 'economy' | 'sports' | 'science' | 'awards';
  published_date: string;
  summary: string;
  details: string;
  source?: string;
  tags: string[];
}

export interface Bookmark {
  id: string;
  user_id: string;
  item_type: 'material' | 'question' | 'current_affair' | 'notice';
  item_id: string;
  created_at: string;
}

export interface AppStats {
  totalAspirants: number;
  totalQuestions: number;
  totalMaterials: number;
  successfulCandidates: number;
}

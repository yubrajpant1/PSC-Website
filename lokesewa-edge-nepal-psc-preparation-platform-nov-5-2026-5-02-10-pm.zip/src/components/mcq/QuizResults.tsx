import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  RotateCcw,
  BookOpen,
  Award,
  Share2,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { McqQuestion, QuizAttempt } from '../../types';

interface QuizResultsProps {
  attempt: QuizAttempt;
  questions: McqQuestion[];
  onRestart: () => void;
  onExploreNotes: () => void;
}

export const QuizResults: React.FC<QuizResultsProps> = ({
  attempt,
  questions,
  onRestart,
  onExploreNotes,
}) => {
  const isPassed = attempt.score_percentage >= 40;
  const isDistinction = attempt.score_percentage >= 80;

  useEffect(() => {
    if (isPassed) {
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // Safe fallback
      }
    }
  }, [isPassed]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      {/* Result Overview Header Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
        <div
          className={`p-6 sm:p-8 text-center text-white ${
            isDistinction
              ? 'bg-gradient-to-br from-emerald-600 to-teal-800'
              : isPassed
              ? 'bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900'
              : 'bg-gradient-to-br from-rose-700 to-slate-900'
          }`}
        >
          <div className="w-16 h-16 rounded-full bg-white/10 mx-auto flex items-center justify-center mb-4 ring-4 ring-white/20">
            {isPassed ? (
              <Award className="w-8 h-8 text-amber-300" />
            ) : (
              <TrendingUp className="w-8 h-8 text-white" />
            )}
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            {isDistinction
              ? 'Outstanding Performance! (उत्कृष्ट नतिजा)'
              : isPassed
              ? 'Congratulations! You Passed! (बधाई छ, उत्तीर्ण)'
              : 'Keep Practicing! (पुनः अभ्यास गर्नुहोस्)'}
          </h2>

          <p className="text-sm text-slate-200 mt-1 max-w-md mx-auto">
            Subject: {attempt.subject_name} • Nepal Loksewa Standard Test
          </p>

          {/* Big Score Percentage Display */}
          <div className="mt-6 inline-flex items-baseline gap-2 bg-white/10 px-6 py-3 rounded-2xl backdrop-blur-xs ring-1 ring-white/20">
            <span className="text-4xl sm:text-5xl font-black">
              {attempt.score_percentage}%
            </span>
            <span className="text-xs uppercase tracking-wider text-slate-300 font-bold">
              Final Score
            </span>
          </div>
        </div>

        {/* Detailed Stats Metrics Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-100 bg-slate-50 border-b border-slate-200 text-center py-4">
          <div className="p-3">
            <span className="text-xs font-semibold text-slate-500 block">Total Questions</span>
            <span className="text-xl font-bold text-slate-800">{attempt.total_questions}</span>
          </div>

          <div className="p-3">
            <span className="text-xs font-semibold text-emerald-600 block flex items-center justify-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Correct Answers
            </span>
            <span className="text-xl font-bold text-emerald-600">{attempt.correct_count}</span>
          </div>

          <div className="p-3">
            <span className="text-xs font-semibold text-rose-600 block flex items-center justify-center gap-1">
              <XCircle className="w-3.5 h-3.5" />
              Incorrect Answers
            </span>
            <span className="text-xl font-bold text-rose-600">{attempt.incorrect_count}</span>
          </div>

          <div className="p-3">
            <span className="text-xs font-semibold text-slate-500 block flex items-center justify-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              Time Spent
            </span>
            <span className="text-xl font-bold text-slate-800">
              {formatTime(attempt.time_spent_seconds)}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 sm:p-6 bg-white flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={onRestart}
            className="py-2.5 px-5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-xs transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Retake Practice Test</span>
          </button>

          <button
            onClick={onExploreNotes}
            className="py-2.5 px-5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-xs transition cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            <span>Read Recommended Notes</span>
          </button>
        </div>
      </div>

      {/* Answer Key Review Breakdown */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <span>Question Review & Explanations</span>
            <span className="text-xs font-normal text-slate-500">(उत्तर पुस्तिका र व्याख्या)</span>
          </h3>
        </div>

        {questions.map((q, idx) => {
          const studentAnswer = attempt.answers.find(a => a.question_id === q.id);
          const isCorrect = studentAnswer?.is_correct;
          const selectedOption = q.options.find(o => o.id === studentAnswer?.selected_option_id);
          const correctOption = q.options.find(o => o.is_correct);

          return (
            <div
              key={q.id}
              className={`bg-white rounded-xl border p-5 transition ${
                isCorrect ? 'border-emerald-200' : 'border-rose-200'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700">
                  Q {idx + 1}
                </span>

                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold flex items-center gap-1 ${
                    isCorrect
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {isCorrect ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Correct (+1.0)
                    </>
                  ) : (
                    <>
                      <XCircle className="w-3.5 h-3.5" />
                      Incorrect (-0.20)
                    </>
                  )}
                </span>
              </div>

              {/* Question Text */}
              <h4 className="text-sm font-semibold text-slate-900 leading-snug">
                {q.question_text}
              </h4>
              {q.question_text_nepali && (
                <p className="text-xs text-slate-600 font-nepali mt-1">
                  {q.question_text_nepali}
                </p>
              )}

              {/* Options Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3 text-xs">
                {q.options.map((opt, oIdx) => {
                  const letter = String.fromCharCode(65 + oIdx);
                  const isSelected = selectedOption?.id === opt.id;
                  const isAnswer = opt.is_correct;

                  let optClass = 'border-slate-200 bg-white text-slate-700';
                  if (isAnswer) {
                    optClass = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold';
                  } else if (isSelected && !isAnswer) {
                    optClass = 'border-rose-400 bg-rose-50 text-rose-900 line-through';
                  }

                  return (
                    <div
                      key={opt.id}
                      className={`p-2.5 rounded-lg border flex items-start gap-2 ${optClass}`}
                    >
                      <span className="font-bold shrink-0">{letter}.</span>
                      <div className="flex-1">
                        <span>{opt.text}</span>
                        {opt.text_nepali && (
                          <span className="block text-[11px] text-slate-500 font-nepali">
                            {opt.text_nepali}
                          </span>
                        )}
                      </div>
                      {isAnswer && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />}
                    </div>
                  );
                })}
              </div>

              {/* Official Explanation Box */}
              <div className="mt-3.5 p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                <span className="font-bold text-orange-600 block mb-1">
                  💡 Explanation (व्याख्या):
                </span>
                <p className="text-slate-700 leading-relaxed">{q.explanation}</p>
                {q.explanation_nepali && (
                  <p className="text-slate-600 font-nepali mt-1 leading-relaxed">
                    {q.explanation_nepali}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

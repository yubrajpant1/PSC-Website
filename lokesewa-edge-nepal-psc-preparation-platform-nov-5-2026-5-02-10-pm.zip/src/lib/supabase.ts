import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Get credentials from environment variables or custom runtime storage
const getEnvSupabaseUrl = () => import.meta.env.VITE_SUPABASE_URL || '';
const getEnvSupabaseAnonKey = () => import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Allow runtime configuration from Admin Settings if desired
const getStoredSupabaseConfig = () => {
  try {
    const stored = localStorage.getItem('loksewa_supabase_config');
    if (stored) {
      return JSON.parse(stored);
    }
  } catch {
    // Ignore error
  }
  return null;
};

const storedConfig = getStoredSupabaseConfig();
export const supabaseUrl = storedConfig?.url || getEnvSupabaseUrl();
export const supabaseAnonKey = storedConfig?.anonKey || getEnvSupabaseAnonKey();

export const isSupabaseConfigured = (): boolean => {
  return Boolean(
    supabaseUrl &&
    supabaseAnonKey &&
    supabaseUrl.startsWith('https://') &&
    supabaseAnonKey.length > 20 &&
    !supabaseUrl.includes('placeholder')
  );
};

export const saveRuntimeSupabaseConfig = (url: string, anonKey: string) => {
  localStorage.setItem('loksewa_supabase_config', JSON.stringify({ url, anonKey }));
  window.location.reload();
};

export const clearRuntimeSupabaseConfig = () => {
  localStorage.removeItem('loksewa_supabase_config');
  window.location.reload();
};

// Initialize Supabase client if configured, otherwise null
export const supabase: SupabaseClient | null = isSupabaseConfigured()
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    })
  : null;

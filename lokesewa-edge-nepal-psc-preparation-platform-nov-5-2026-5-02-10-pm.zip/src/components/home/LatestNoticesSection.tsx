import React from 'react';
import {
  Bell,
  Calendar,
  ExternalLink,
  ArrowRight,
  Clock,
  Download,
} from 'lucide-react';
import { useData } from '../../context/DataContext';

interface LatestNoticesSectionProps {
  onViewAllNotices: () => void;
}

export const LatestNoticesSection: React.FC<LatestNoticesSectionProps> = ({
  onViewAllNotices,
}) => {
  const { notices } = useData();

  // Show top 3 notices
  const latest = notices.slice(0, 3);

  return (
    <section className="py-12 bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 mb-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
              <span>PSC Official Broadcast</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Latest Notices & Examination Updates
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 font-nepali mt-1">
              लोकसेवा आयोगद्वारा प्रकाशित पछिल्ला विज्ञापन तथा परीक्षा सम्बन्धी सूचनाहरू
            </p>
          </div>

          <button
            onClick={onViewAllNotices}
            className="text-xs sm:text-sm font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <span>View All Notices & Routine</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {latest.map(notice => (
            <div
              key={notice.id}
              className={`p-5 rounded-2xl border flex flex-col justify-between transition hover:shadow-md ${
                notice.is_urgent ? 'border-orange-300 bg-orange-50/20' : 'border-slate-200 bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                    {notice.type.replace('_', ' ')}
                  </span>
                  <span className="flex items-center gap-1 text-[11px] text-slate-400">
                    <Calendar className="w-3 h-3" />
                    <span>{notice.published_date}</span>
                  </span>
                </div>

                <h3 className="font-bold text-sm text-slate-900 leading-snug line-clamp-2">
                  {notice.title}
                </h3>
                {notice.nepali_title && (
                  <p className="text-[11px] text-slate-500 font-nepali mt-1 line-clamp-1">
                    {notice.nepali_title}
                  </p>
                )}

                <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                  {notice.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                {notice.deadline_date ? (
                  <span className="text-[11px] font-semibold text-rose-600 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>Deadline: {notice.deadline_date}</span>
                  </span>
                ) : (
                  <span className="text-[11px] text-slate-400">Notice Published</span>
                )}

                {notice.external_link && (
                  <a
                    href={notice.external_link}
                    target="_blank"
                    rel="noreferrer"
                    className="text-orange-600 font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Official Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

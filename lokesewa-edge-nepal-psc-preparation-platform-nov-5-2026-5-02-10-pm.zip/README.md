# Lokesewa Edge – Nepal PSC (Loksewa Aayog) Preparation Platform
> **Tagline:** *Prepare Smart. Achieve More.*
> **Nepali:** *स्मार्ट तयारी, सफल नतिजा*

Lokesewa Edge is a modern, responsive educational web application designed for students preparing for Nepal's Public Service Commission (Lok Sewa Aayog / PSC) examinations.

---

## 🚀 Key Features

### 1. Study Materials & PDF Library
- **Subject-Wise Organization:** Dedicated sections for Civil Engineering (4th, 5th, 7th level), Constitution of Nepal 2072, Nepal General Knowledge, Census 2078 demographics, and Speed IQ.
- **Interactive PDF Viewer:** In-browser document preview, syllabus unit breakdowns, and download manager.
- **Search & Filters:** Real-time search across English and Nepali Unicode terms, filter by PSC exam level and topic.

### 2. MCQ Practice System & Timed Simulator
- **Two Practice Modes:**
  1. *Learning Practice Mode:* Instant feedback after selecting any option, showing correct answer and comprehensive explanations in both English and Nepali.
  2. *Simulated PSC Timed Exam:* Real examination countdown timer, question jump palette, and official PSC negative marking rule (-0.20 deduction per incorrect answer).
- **Comprehensive Scorecard:** Total questions, accuracy percentage, time spent, pass/fail status, and question-by-question mistake review with confetti animations.

### 3. GK, IQ & Current Affairs Capsules
- **High-Yield Facts:** Census 2078 official results, 16th Periodic Plan priorities, National Parks & Rivers, International Treaties (SAARC, BIMSTEC, UN).
- **Daily Capsules:** Monthly national and international updates, economic survey highlights, and sports milestones.

### 4. Official PSC Notices & Routines
- Live feed of vacancy announcements with application deadlines, examination routine schedules, and result PDFs.

### 5. Student Accounts & Personal Dashboard
- Real authentication via Supabase Auth (with offline preview storage fallback).
- Track quiz attempts, average accuracy rates, bookmarked study notes, and custom PSC target exams.

### 6. Protected Admin Control Panel
- Manage Study Materials & PDF uploads.
- Create, update, and delete MCQ questions with 4 choices and explanations.
- Broadcast vacancy notices with deadlines.
- **Supabase Cloud Connector & Schema Exporter:** Test connection and copy the full PostgreSQL database schema into Supabase SQL editor with one click.

---

## 🛠️ Technology Stack
- **Frontend:** React 19, TypeScript, Vite
- **Styling:** Tailwind CSS v4, Lucide Icons, Plus Jakarta Sans & Noto Sans Devanagari typography
- **Database & Auth:** Supabase (PostgreSQL, Supabase Auth, Storage) with persistent local fallback
- **Interactive Effects:** Canvas Confetti

---

## ⚙️ Setup & Supabase Integration Guide

### Step 1: Clone and Install
```bash
npm install
npm run dev
```

### Step 2: Supabase Database Provisioning
1. Sign in to your [Supabase Dashboard](https://supabase.com).
2. Create a new free project.
3. Open the **SQL Editor** in Supabase and run the provided SQL script:
   - File: `/supabase-schema.sql`
   - This sets up all 9 relational tables (`profiles`, `subjects`, `study_materials`, `mcq_questions`, `mcq_options`, `quiz_attempts`, `notices`, `current_affairs`, `bookmarks`), Row Level Security (RLS) policies, and triggers.
4. (Optional) Go to **Storage**, create a public bucket named `study-materials`.

### Step 3: Configure Environment Variables
Copy `.env.example` to `.env`:
```env
VITE_SUPABASE_URL="https://your-project-id.supabase.co"
VITE_SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

*Note: You can also configure Supabase credentials at runtime directly through the Admin Dashboard under the "Supabase Database Sync" tab.*

---

## 🔒 Security Best Practices
- Supabase anonymous keys (`anon key`) are safe for public frontend usage.
- Service-role secret keys are **never** exposed in frontend code.
- Row Level Security (RLS) guarantees students can only modify their own quiz attempts and bookmarks, while admin operations require verified administrator roles.

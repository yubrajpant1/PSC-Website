-- =========================================================================
-- LOKESEWA EDGE - COMPLETE SUPABASE POSTGRESQL DATABASE SCHEMA
-- "Prepare Smart. Achieve More."
-- =========================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PROFILES TABLE (Linked with Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'admin')),
    target_exam TEXT DEFAULT 'Civil Engineering 5th Level',
    phone TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. SUBJECTS TABLE
CREATE TABLE IF NOT EXISTS public.subjects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    nepali_name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT,
    icon_name TEXT DEFAULT 'BookOpen',
    total_notes INTEGER DEFAULT 0,
    total_questions INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. STUDY MATERIALS & PDF NOTES TABLE
CREATE TABLE IF NOT EXISTS public.study_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    nepali_title TEXT,
    subject_id TEXT REFERENCES public.subjects(id) ON DELETE SET NULL,
    subject_name TEXT NOT NULL,
    category TEXT NOT NULL,
    level TEXT NOT NULL DEFAULT 'All Levels',
    description TEXT NOT NULL,
    file_url TEXT NOT NULL,
    file_size TEXT DEFAULT '2.5 MB',
    page_count INTEGER DEFAULT 1,
    downloads_count INTEGER DEFAULT 0,
    author TEXT DEFAULT 'Lokesewa Edge',
    is_featured BOOLEAN DEFAULT false,
    tags TEXT[] DEFAULT ARRAY[]::TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. MCQ QUESTIONS TABLE
CREATE TABLE IF NOT EXISTS public.mcq_questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_id TEXT REFERENCES public.subjects(id) ON DELETE SET NULL,
    subject_name TEXT NOT NULL,
    category TEXT NOT NULL,
    topic TEXT NOT NULL,
    level TEXT NOT NULL DEFAULT 'All Levels',
    question_text TEXT NOT NULL,
    question_text_nepali TEXT,
    explanation TEXT NOT NULL,
    explanation_nepali TEXT,
    difficulty TEXT NOT NULL DEFAULT 'medium' CHECK (difficulty IN ('easy', 'medium', 'hard')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. MCQ OPTIONS TABLE
CREATE TABLE IF NOT EXISTS public.mcq_options (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    question_id UUID NOT NULL REFERENCES public.mcq_questions(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    text_nepali TEXT,
    is_correct BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 6. QUIZ ATTEMPTS TABLE (Student Performance Tracking)
CREATE TABLE IF NOT EXISTS public.quiz_attempts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    user_name TEXT,
    subject_id TEXT,
    subject_name TEXT NOT NULL,
    total_questions INTEGER NOT NULL,
    correct_count INTEGER NOT NULL,
    incorrect_count INTEGER NOT NULL,
    unanswered_count INTEGER NOT NULL DEFAULT 0,
    score_percentage NUMERIC(5, 2) NOT NULL,
    time_spent_seconds INTEGER NOT NULL DEFAULT 0,
    answers JSONB DEFAULT '[]'::jsonb,
    attempted_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 7. NOTICES & EXAM VACANCY TABLE
CREATE TABLE IF NOT EXISTS public.notices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    nepali_title TEXT,
    type TEXT NOT NULL CHECK (type IN ('vacancy', 'exam_routine', 'result', 'admit_card', 'syllabus_update', 'general')),
    published_date DATE NOT NULL DEFAULT CURRENT_DATE,
    deadline_date DATE,
    description TEXT NOT NULL,
    pdf_url TEXT,
    external_link TEXT,
    is_active BOOLEAN DEFAULT true,
    is_urgent BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 8. CURRENT AFFAIRS & GK CAPSULES
CREATE TABLE IF NOT EXISTS public.current_affairs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    nepali_title TEXT,
    category TEXT NOT NULL CHECK (category IN ('national', 'international', 'economy', 'sports', 'science', 'awards')),
    published_date DATE NOT NULL DEFAULT CURRENT_DATE,
    summary TEXT NOT NULL,
    details TEXT NOT NULL,
    source TEXT,
    tags TEXT[] DEFAULT ARRAY[]::TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 9. BOOKMARKS TABLE
CREATE TABLE IF NOT EXISTS public.bookmarks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    item_type TEXT NOT NULL CHECK (item_type IN ('material', 'question', 'current_affair', 'notice')),
    item_id TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, item_type, item_id)
);

-- =========================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- =========================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.study_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mcq_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mcq_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.current_affairs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can view their own profile, admins can view all
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles
    FOR SELECT USING (true);

CREATE POLICY "Users can insert their own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

-- Public read for study materials, questions, options, notices, current affairs
CREATE POLICY "Public read subjects" ON public.subjects
    FOR SELECT USING (true);

CREATE POLICY "Public read study_materials" ON public.study_materials
    FOR SELECT USING (true);

CREATE POLICY "Public read mcq_questions" ON public.mcq_questions
    FOR SELECT USING (true);

CREATE POLICY "Public read mcq_options" ON public.mcq_options
    FOR SELECT USING (true);

CREATE POLICY "Public read notices" ON public.notices
    FOR SELECT USING (true);

CREATE POLICY "Public read current_affairs" ON public.current_affairs
    FOR SELECT USING (true);

-- Quiz Attempts: Users can read and insert their own attempts
CREATE POLICY "Users can read own quiz attempts" ON public.quiz_attempts
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own quiz attempts" ON public.quiz_attempts
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Bookmarks: Users manage their own bookmarks
CREATE POLICY "Users can manage own bookmarks" ON public.bookmarks
    FOR ALL USING (auth.uid() = user_id);

-- Admin full access policies using JWT role check or profile role
CREATE POLICY "Admin write access subjects" ON public.subjects
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Admin write access study_materials" ON public.study_materials
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Admin write access mcq_questions" ON public.mcq_questions
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Admin write access mcq_options" ON public.mcq_options
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Admin write access notices" ON public.notices
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Admin write access current_affairs" ON public.current_affairs
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
    );

-- =========================================================================
-- AUTOMATIC PROFILE CREATION TRIGGER ON SIGNUP
-- =========================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name, role)
    VALUES (
        new.id,
        new.email,
        COALESCE(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
        COALESCE(new.raw_user_meta_data->>'role', 'student')
    );
    RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- =========================================================================
-- STORAGE BUCKET FOR STUDY MATERIALS (Run in SQL Editor)
-- =========================================================================
-- INSERT INTO storage.buckets (id, name, public) 
-- VALUES ('study-materials', 'study-materials', true)
-- ON CONFLICT (id) DO NOTHING;

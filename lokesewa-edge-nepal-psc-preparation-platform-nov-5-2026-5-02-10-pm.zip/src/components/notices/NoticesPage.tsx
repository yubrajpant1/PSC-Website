import React, { useState, useMemo } from 'react';
import {
  Bell,
  Calendar,
  ExternalLink,
  Download,
  AlertCircle,
  Clock,
  Filter,
  CheckCircle2,
  FileText,
  Search,
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { Notice, NoticeType } from '../../types';

export const NoticesPage: React.FC = () => {
  const { notices } = useData();
  const [selectedType, setSelectedType] = useState<NoticeType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredNotices = useMemo(() => {
    return notices.filter(n => {
      const matchesType = selectedType === 'all' || n.type === selectedType;
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        n.title.toLowerCase().includes(query) ||
        (n.nepali_title && n.nepali_title.toLowerCase().includes(query)) ||
        n.description.toLowerCase().includes(query);

      return matchesType && matchesSearch;
    });
  }, [notices, selectedType, searchQuery]);

  const typeBadges: Record<NoticeType, { label: string; color: string }> = {
    vacancy: { label: 'Vacancy (विज्ञापन)', color: 'bg-emerald-100 text-emerald-800' },
    exam_routine: { label: 'Exam Routine (परीक्षा तालिका)', color: 'bg-blue-100 text-blue-800' },
    result: { label: 'Result (नतिजा)', color: 'bg-purple-100 text-purple-800' },
    admit_card: { label: 'Admit Card (प्रवेशपत्र)', color: 'bg-amber-100 text-amber-800' },
    syllabus_update: { label: 'Syllabus (पाठ्यक्रम)', color: 'bg-cyan-100 text-cyan-800' },
    general: { label: 'General (सूचना)', color: 'bg-slate-100 text-slate-800' },
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 sm:py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-700 mb-2">
            <Bell className="w-3.5 h-3.5" />
            <span>Public Service Commission Live Feed</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            PSC Notices & Examination Updates
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl font-nepali">
            लोक सेवा आयोग (PSC), प्रदेश लोक सेवा आयोगहरू, पदपूर्ति विज्ञापन, परीक्षा तालिका र नतिजाहरू
          </p>
        </div>

        {/* Filter Bar */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="w-full md:w-80 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search notices, exams, posts..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-slate-50/50"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
              {[
                { id: 'all', label: 'All Notices' },
                { id: 'vacancy', label: 'Vacancies' },
                { id: 'exam_routine', label: 'Routines' },
                { id: 'result', label: 'Results' },
                { id: 'admit_card', label: 'Admit Cards' },
              ].map(type => (
                <button
                  key={type.id}
                  onClick={() => setSelectedType(type.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                    selectedType === type.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {type.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Notices Timeline / Cards */}
        <div className="space-y-4">
          {filteredNotices.length === 0 ? (
            <div className="bg-white rounded-xl p-10 text-center border border-slate-200">
              <Bell className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-700">No notices found.</p>
              <p className="text-xs text-slate-400 mt-0.5">Please check again soon or clear filters.</p>
            </div>
          ) : (
            filteredNotices.map(notice => {
              const badge = typeBadges[notice.type] || typeBadges.general;

              return (
                <div
                  key={notice.id}
                  className={`bg-white rounded-xl shadow-xs border p-5 sm:p-6 transition hover:shadow-md ${
                    notice.is_urgent ? 'border-orange-300 ring-1 ring-orange-200' : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${badge.color}`}>
                          {badge.label}
                        </span>

                        {notice.is_urgent && (
                          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-red-100 text-red-700 animate-pulse">
                            🚨 Urgent Notice
                          </span>
                        )}

                        <span className="flex items-center gap-1 text-[11px] text-slate-400">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>Published: {notice.published_date}</span>
                        </span>

                        {notice.deadline_date && (
                          <span className="flex items-center gap-1 text-[11px] text-rose-600 font-semibold bg-rose-50 px-2 py-0.5 rounded">
                            <Clock className="w-3.5 h-3.5" />
                            <span>Deadline: {notice.deadline_date}</span>
                          </span>
                        )}
                      </div>

                      <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                        {notice.title}
                      </h3>
                      {notice.nepali_title && (
                        <p className="text-xs sm:text-sm text-slate-600 font-nepali mt-1">
                          {notice.nepali_title}
                        </p>
                      )}

                      <p className="text-xs sm:text-sm text-slate-600 mt-2.5 leading-relaxed">
                        {notice.description}
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex sm:flex-col gap-2 shrink-0">
                      {notice.external_link && (
                        <a
                          href={notice.external_link}
                          target="_blank"
                          rel="noreferrer"
                          className="py-1.5 px-3 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                        >
                          <span>Official Portal</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}

                      {notice.pdf_url && (
                        <a
                          href={notice.pdf_url}
                          target="_blank"
                          rel="noreferrer"
                          className="py-1.5 px-3 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download PDF</span>
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

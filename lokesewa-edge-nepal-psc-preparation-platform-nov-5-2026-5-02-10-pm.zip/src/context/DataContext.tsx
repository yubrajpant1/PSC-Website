import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import {
  StudyMaterial,
  McqQuestion,
  Notice,
  CurrentAffair,
  QuizAttempt,
  Bookmark,
  Subject,
} from '../types';
import {
  initialMaterials,
  initialQuestions,
  initialNotices,
  initialCurrentAffairs,
  initialSubjects,
} from '../data/initialData';

interface DataContextType {
  subjects: Subject[];
  materials: StudyMaterial[];
  questions: McqQuestion[];
  notices: Notice[];
  currentAffairs: CurrentAffair[];
  quizAttempts: QuizAttempt[];
  bookmarks: Bookmark[];
  loading: boolean;
  isSupabaseActive: boolean;

  // Study Materials Actions
  addMaterial: (material: Omit<StudyMaterial, 'id' | 'created_at' | 'downloads_count'>) => Promise<boolean>;
  updateMaterial: (id: string, updates: Partial<StudyMaterial>) => Promise<boolean>;
  deleteMaterial: (id: string) => Promise<boolean>;
  incrementDownload: (id: string) => void;

  // MCQ Question Actions
  addQuestion: (question: Omit<McqQuestion, 'id' | 'created_at'>) => Promise<boolean>;
  updateQuestion: (id: string, updates: Partial<McqQuestion>) => Promise<boolean>;
  deleteQuestion: (id: string) => Promise<boolean>;

  // Notice Actions
  addNotice: (notice: Omit<Notice, 'id'>) => Promise<boolean>;
  updateNotice: (id: string, updates: Partial<Notice>) => Promise<boolean>;
  deleteNotice: (id: string) => Promise<boolean>;

  // Current Affairs Actions
  addCurrentAffair: (affair: Omit<CurrentAffair, 'id'>) => Promise<boolean>;
  updateCurrentAffair: (id: string, updates: Partial<CurrentAffair>) => Promise<boolean>;
  deleteCurrentAffair: (id: string) => Promise<boolean>;

  // Student Actions
  saveQuizAttempt: (attempt: Omit<QuizAttempt, 'id' | 'attempted_at'>) => Promise<QuizAttempt>;
  toggleBookmark: (itemType: Bookmark['item_type'], itemId: string, userId?: string) => void;
  isBookmarked: (itemType: Bookmark['item_type'], itemId: string) => boolean;

  // Reset to sample data
  resetToSampleData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const isSupabaseActive = isSupabaseConfigured();
  const [loading, setLoading] = useState(false);

  // States with localStorage persistence defaults
  const [subjects] = useState<Subject[]>(initialSubjects);
  
  const [materials, setMaterials] = useState<StudyMaterial[]>(() => {
    try {
      const saved = localStorage.getItem('loksewa_materials');
      return saved ? JSON.parse(saved) : initialMaterials;
    } catch {
      return initialMaterials;
    }
  });

  const [questions, setQuestions] = useState<McqQuestion[]>(() => {
    try {
      const saved = localStorage.getItem('loksewa_questions');
      return saved ? JSON.parse(saved) : initialQuestions;
    } catch {
      return initialQuestions;
    }
  });

  const [notices, setNotices] = useState<Notice[]>(() => {
    try {
      const saved = localStorage.getItem('loksewa_notices');
      return saved ? JSON.parse(saved) : initialNotices;
    } catch {
      return initialNotices;
    }
  });

  const [currentAffairs, setCurrentAffairs] = useState<CurrentAffair[]>(() => {
    try {
      const saved = localStorage.getItem('loksewa_current_affairs');
      return saved ? JSON.parse(saved) : initialCurrentAffairs;
    } catch {
      return initialCurrentAffairs;
    }
  });

  const [quizAttempts, setQuizAttempts] = useState<QuizAttempt[]>(() => {
    try {
      const saved = localStorage.getItem('loksewa_quiz_attempts');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    try {
      const saved = localStorage.getItem('loksewa_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save to localStorage whenever local states change
  useEffect(() => {
    localStorage.setItem('loksewa_materials', JSON.stringify(materials));
  }, [materials]);

  useEffect(() => {
    localStorage.setItem('loksewa_questions', JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem('loksewa_notices', JSON.stringify(notices));
  }, [notices]);

  useEffect(() => {
    localStorage.setItem('loksewa_current_affairs', JSON.stringify(currentAffairs));
  }, [currentAffairs]);

  useEffect(() => {
    localStorage.setItem('loksewa_quiz_attempts', JSON.stringify(quizAttempts));
  }, [quizAttempts]);

  useEffect(() => {
    localStorage.setItem('loksewa_bookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  // If Supabase is connected, optionally pull live database rows
  useEffect(() => {
    if (!isSupabaseActive || !supabase) return;

    let isMounted = true;
    async function fetchFromSupabase() {
      setLoading(true);
      try {
        const [matRes, qRes, notRes, caRes] = await Promise.allSettled([
          supabase!.from('study_materials').select('*').order('created_at', { ascending: false }),
          supabase!.from('mcq_questions').select('*, mcq_options(*)'),
          supabase!.from('notices').select('*').order('published_date', { ascending: false }),
          supabase!.from('current_affairs').select('*').order('published_date', { ascending: false }),
        ]);

        if (isMounted) {
          if (matRes.status === 'fulfilled' && matRes.value.data && matRes.value.data.length > 0) {
            setMaterials(matRes.value.data as StudyMaterial[]);
          }
          if (qRes.status === 'fulfilled' && qRes.value.data && qRes.value.data.length > 0) {
            const formattedQ: McqQuestion[] = qRes.value.data.map((q: any) => ({
              id: q.id,
              subject_id: q.subject_id,
              subject_name: q.subject_name,
              category: q.category,
              topic: q.topic,
              level: q.level,
              question_text: q.question_text,
              question_text_nepali: q.question_text_nepali,
              explanation: q.explanation,
              explanation_nepali: q.explanation_nepali,
              difficulty: q.difficulty,
              created_at: q.created_at,
              options: (q.mcq_options || []).map((o: any) => ({
                id: o.id,
                text: o.text,
                text_nepali: o.text_nepali,
                is_correct: o.is_correct,
              })),
            }));
            setQuestions(formattedQ);
          }
          if (notRes.status === 'fulfilled' && notRes.value.data && notRes.value.data.length > 0) {
            setNotices(notRes.value.data as Notice[]);
          }
          if (caRes.status === 'fulfilled' && caRes.value.data && caRes.value.data.length > 0) {
            setCurrentAffairs(caRes.value.data as CurrentAffair[]);
          }
        }
      } catch (err) {
        console.warn('Supabase fetch notice, using cached local data:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    fetchFromSupabase();

    return () => {
      isMounted = false;
    };
  }, [isSupabaseActive]);

  // MATERIAL ACTIONS
  const addMaterial = async (item: Omit<StudyMaterial, 'id' | 'created_at' | 'downloads_count'>): Promise<boolean> => {
    const newMaterial: StudyMaterial = {
      ...item,
      id: 'mat-' + Date.now(),
      created_at: new Date().toISOString().split('T')[0],
      downloads_count: 0,
    };

    setMaterials(prev => [newMaterial, ...prev]);

    if (isSupabaseActive && supabase) {
      try {
        await supabase.from('study_materials').insert([newMaterial]);
      } catch (e) {
        console.error('Supabase material insert error:', e);
      }
    }
    return true;
  };

  const updateMaterial = async (id: string, updates: Partial<StudyMaterial>): Promise<boolean> => {
    setMaterials(prev => prev.map(m => (m.id === id ? { ...m, ...updates } : m)));
    if (isSupabaseActive && supabase) {
      try {
        await supabase.from('study_materials').update(updates).eq('id', id);
      } catch (e) {
        console.error('Supabase material update error:', e);
      }
    }
    return true;
  };

  const deleteMaterial = async (id: string): Promise<boolean> => {
    setMaterials(prev => prev.filter(m => m.id !== id));
    if (isSupabaseActive && supabase) {
      try {
        await supabase.from('study_materials').delete().eq('id', id);
      } catch (e) {
        console.error('Supabase material delete error:', e);
      }
    }
    return true;
  };

  const incrementDownload = (id: string) => {
    setMaterials(prev =>
      prev.map(m => (m.id === id ? { ...m, downloads_count: m.downloads_count + 1 } : m))
    );
  };

  // MCQ QUESTION ACTIONS
  const addQuestion = async (q: Omit<McqQuestion, 'id' | 'created_at'>): Promise<boolean> => {
    const newQuestion: McqQuestion = {
      ...q,
      id: 'q-' + Date.now(),
      created_at: new Date().toISOString().split('T')[0],
    };
    setQuestions(prev => [newQuestion, ...prev]);
    return true;
  };

  const updateQuestion = async (id: string, updates: Partial<McqQuestion>): Promise<boolean> => {
    setQuestions(prev => prev.map(q => (q.id === id ? { ...q, ...updates } : q)));
    return true;
  };

  const deleteQuestion = async (id: string): Promise<boolean> => {
    setQuestions(prev => prev.filter(q => q.id !== id));
    return true;
  };

  // NOTICE ACTIONS
  const addNotice = async (n: Omit<Notice, 'id'>): Promise<boolean> => {
    const newNotice: Notice = {
      ...n,
      id: 'not-' + Date.now(),
    };
    setNotices(prev => [newNotice, ...prev]);
    return true;
  };

  const updateNotice = async (id: string, updates: Partial<Notice>): Promise<boolean> => {
    setNotices(prev => prev.map(n => (n.id === id ? { ...n, ...updates } : n)));
    return true;
  };

  const deleteNotice = async (id: string): Promise<boolean> => {
    setNotices(prev => prev.filter(n => n.id !== id));
    return true;
  };

  // CURRENT AFFAIRS ACTIONS
  const addCurrentAffair = async (c: Omit<CurrentAffair, 'id'>): Promise<boolean> => {
    const newAffair: CurrentAffair = {
      ...c,
      id: 'ca-' + Date.now(),
    };
    setCurrentAffairs(prev => [newAffair, ...prev]);
    return true;
  };

  const updateCurrentAffair = async (id: string, updates: Partial<CurrentAffair>): Promise<boolean> => {
    setCurrentAffairs(prev => prev.map(c => (c.id === id ? { ...c, ...updates } : c)));
    return true;
  };

  const deleteCurrentAffair = async (id: string): Promise<boolean> => {
    setCurrentAffairs(prev => prev.filter(c => c.id !== id));
    return true;
  };

  // STUDENT ACTIONS
  const saveQuizAttempt = async (attemptData: Omit<QuizAttempt, 'id' | 'attempted_at'>): Promise<QuizAttempt> => {
    const newAttempt: QuizAttempt = {
      ...attemptData,
      id: 'att-' + Date.now(),
      attempted_at: new Date().toISOString(),
    };
    setQuizAttempts(prev => [newAttempt, ...prev]);

    if (isSupabaseActive && supabase && attemptData.user_id && !attemptData.user_id.startsWith('local-')) {
      try {
        await supabase.from('quiz_attempts').insert([newAttempt]);
      } catch (e) {
        console.warn('Supabase quiz attempt insert fallback:', e);
      }
    }
    return newAttempt;
  };

  const toggleBookmark = (itemType: Bookmark['item_type'], itemId: string, userId = 'local-user') => {
    const existingIndex = bookmarks.findIndex(
      b => b.item_type === itemType && b.item_id === itemId
    );
    if (existingIndex > -1) {
      setBookmarks(prev => prev.filter((_, idx) => idx !== existingIndex));
    } else {
      const newBm: Bookmark = {
        id: 'bm-' + Date.now(),
        user_id: userId,
        item_type: itemType,
        item_id: itemId,
        created_at: new Date().toISOString(),
      };
      setBookmarks(prev => [newBm, ...prev]);
    }
  };

  const isBookmarked = (itemType: Bookmark['item_type'], itemId: string): boolean => {
    return bookmarks.some(b => b.item_type === itemType && b.item_id === itemId);
  };

  const resetToSampleData = () => {
    setMaterials(initialMaterials);
    setQuestions(initialQuestions);
    setNotices(initialNotices);
    setCurrentAffairs(initialCurrentAffairs);
    setQuizAttempts([]);
    setBookmarks([]);
    localStorage.removeItem('loksewa_materials');
    localStorage.removeItem('loksewa_questions');
    localStorage.removeItem('loksewa_notices');
    localStorage.removeItem('loksewa_current_affairs');
    localStorage.removeItem('loksewa_quiz_attempts');
    localStorage.removeItem('loksewa_bookmarks');
  };

  return (
    <DataContext.Provider
      value={{
        subjects,
        materials,
        questions,
        notices,
        currentAffairs,
        quizAttempts,
        bookmarks,
        loading,
        isSupabaseActive,
        addMaterial,
        updateMaterial,
        deleteMaterial,
        incrementDownload,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        addNotice,
        updateNotice,
        deleteNotice,
        addCurrentAffair,
        updateCurrentAffair,
        deleteCurrentAffair,
        saveQuizAttempt,
        toggleBookmark,
        isBookmarked,
        resetToSampleData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

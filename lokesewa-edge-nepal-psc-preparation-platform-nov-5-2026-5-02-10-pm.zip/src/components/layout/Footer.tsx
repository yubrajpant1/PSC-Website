import React from 'react';
import { Logo } from '../common/Logo';
import { MapPin, Mail, Phone, ExternalLink, Shield, BookOpen, Award, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string, params?: any) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-slate-800">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <Logo size="lg" light />
            <p className="text-sm text-slate-400 max-w-sm leading-relaxed">
              Nepal's dedicated digital platform for Public Service Commission (Lok Sewa Aayog) aspirants. High-yield PDF notes, interactive MCQ simulators, Civil Engineering guides, and real-time vacancy updates.
            </p>

            <div className="space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-orange-500 shrink-0" />
                <span>Bagbazar & Maitighar, Kathmandu, Nepal</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-500 shrink-0" />
                <span>support@loksewaedge.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-orange-500 shrink-0" />
                <span>+977-1-4220000 / +977-9800000000</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-orange-500" />
              <span>Explore Prep</span>
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('materials')}
                  className="hover:text-white hover:underline text-left cursor-pointer transition"
                >
                  Download PDF Notes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('mcq')}
                  className="hover:text-white hover:underline text-left cursor-pointer transition"
                >
                  Practice MCQ Questions
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('gk')}
                  className="hover:text-white hover:underline text-left cursor-pointer transition"
                >
                  Nepal GK & Census 2078
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('gk')}
                  className="hover:text-white hover:underline text-left cursor-pointer transition"
                >
                  Current Affairs Capsules
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('notices')}
                  className="hover:text-white hover:underline text-left cursor-pointer transition"
                >
                  PSC Vacancies & Results
                </button>
              </li>
            </ul>
          </div>

          {/* Exam Programs */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-orange-500" />
              <span>Key PSC Tracks</span>
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => onNavigate('materials', { category: 'civil_engineering' })}
                  className="hover:text-white hover:underline text-left cursor-pointer"
                >
                  Civil Sub-Engineer (5th Level)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('materials', { category: 'civil_engineering' })}
                  className="hover:text-white hover:underline text-left cursor-pointer"
                >
                  Civil Engineer (7th Level)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('materials', { category: 'governance_law' })}
                  className="hover:text-white hover:underline text-left cursor-pointer"
                >
                  Section Officer (शाखा अधिकृत)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('materials', { category: 'iq_reasoning' })}
                  className="hover:text-white hover:underline text-left cursor-pointer"
                >
                  Nayab Subba & Kharidar
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('materials', { category: 'nepal_gk' })}
                  className="hover:text-white hover:underline text-left cursor-pointer"
                >
                  General Administration & Law
                </button>
              </li>
            </ul>
          </div>

          {/* Official Government Portals */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-orange-500" />
              <span>Official Portals</span>
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <a
                  href="http://psc.gov.np"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white flex items-center gap-1.5 group"
                >
                  <span>PSC Central Office (लोकसेवा)</span>
                  <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-orange-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://psconline.psc.gov.np"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white flex items-center gap-1.5 group"
                >
                  <span>PSC Online Application</span>
                  <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-orange-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://lawcommission.gov.np"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white flex items-center gap-1.5 group"
                >
                  <span>Nepal Law Commission</span>
                  <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-orange-400" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.ppmo.gov.np"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white flex items-center gap-1.5 group"
                >
                  <span>PPMO (Public Procurement)</span>
                  <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-orange-400" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Credits & Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} Lokesewa Edge. All rights reserved.</span>
            <span>•</span>
            <span className="font-nepali">स्मार्ट तयारी, सफल नतिजा</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span className="flex items-center gap-1 text-[11px] text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Verified PSC Syllabus Aligned
            </span>
            <span>•</span>
            <span>Privacy Policy</span>
            <span>•</span>
            <span>Terms of Study</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

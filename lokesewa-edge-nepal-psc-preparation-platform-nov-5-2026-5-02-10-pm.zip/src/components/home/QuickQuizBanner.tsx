import React from 'react';
import { CheckSquare, ArrowRight, Clock, Award, ShieldAlert } from 'lucide-react';

interface QuickQuizBannerProps {
  onStartQuiz: () => void;
}

export const QuickQuizBanner: React.FC<QuickQuizBannerProps> = ({ onStartQuiz }) => {
  return (
    <section className="py-12 bg-slate-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-orange-600/10 via-amber-500/10 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="bg-gradient-to-r from-slate-900 to-navy-900 rounded-3xl p-8 sm:p-12 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-4 max-w-xl text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-600/20 text-orange-400 border border-orange-500/30">
              <Clock className="w-3.5 h-3.5" />
              <span>Free Diagnostic Mock Exam</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Test Your Loksewa Readiness in 5 Minutes
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Experience the authentic Nepal PSC computer test interface. Realistic questions covering Civil Engineering specifications, Census 2078 demographics, Constitution 2072 articles, and fast IQ number series with instant scorecard analysis.
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-slate-300">
              <span className="flex items-center gap-1">
                <CheckSquare className="w-4 h-4 text-emerald-400" />
                <span>4 Choices per Question</span>
              </span>
              <span className="flex items-center gap-1">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <span>-0.20 Negative Marking Simulation</span>
              </span>
              <span className="flex items-center gap-1">
                <Award className="w-4 h-4 text-orange-400" />
                <span>Instant Answer Key Review</span>
              </span>
            </div>
          </div>

          <div className="shrink-0">
            <button
              onClick={onStartQuiz}
              className="py-3.5 px-8 rounded-2xl bg-orange-600 hover:bg-orange-700 text-white font-extrabold text-sm sm:text-base shadow-xl shadow-orange-600/30 flex items-center gap-2.5 transition hover:scale-105 cursor-pointer"
            >
              <CheckSquare className="w-5 h-5" />
              <span>Launch Mock Test</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

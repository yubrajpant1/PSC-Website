import React, { useState } from 'react';
import {
  User,
  Award,
  BookOpen,
  Bookmark,
  Clock,
  CheckCircle2,
  TrendingUp,
  Target,
  Edit2,
  Trash2,
  FileText,
  Calendar,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';

interface StudentDashboardProps {
  onNavigate: (view: string, params?: any) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onNavigate }) => {
  const { user, updateProfile } = useAuth();
  const { quizAttempts, bookmarks, materials, currentAffairs } = useData();

  const [activeTab, setActiveTab] = useState<'overview' | 'tests' | 'bookmarks' | 'profile'>('overview');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [fullName, setFullName] = useState(user?.full_name || '');
  const [targetExam, setTargetExam] = useState(user?.target_exam || 'Civil Engineering 5th Level');
  const [phone, setPhone] = useState(user?.phone || '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Filter student attempts (match user or guest)
  const studentAttempts = quizAttempts.filter(
    a => a.user_id === user?.id || (user?.id.startsWith('local-') && a.user_id.startsWith('local-')) || a.user_id === 'guest'
  );

  // Bookmarked materials
  const savedMaterials = materials.filter(m =>
    bookmarks.some(b => b.item_type === 'material' && b.item_id === m.id)
  );

  // Bookmarked current affairs
  const savedAffairs = currentAffairs.filter(c =>
    bookmarks.some(b => b.item_type === 'current_affair' && b.item_id === c.id)
  );

  // Calculate statistics
  const totalTests = studentAttempts.length;
  const avgScore = totalTests > 0
    ? Math.round(studentAttempts.reduce((acc, curr) => acc + curr.score_percentage, 0) / totalTests)
    : 0;
  const totalQuestionsSolved = studentAttempts.reduce((acc, curr) => acc + curr.total_questions, 0);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({
      full_name: fullName,
      target_exam: targetExam,
      phone,
    });
    setSaveSuccess(true);
    setIsEditingProfile(false);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 sm:py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Banner */}
        <div className="bg-slate-900 rounded-2xl shadow-sm text-white p-6 sm:p-8 mb-8 relative overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white font-extrabold text-2xl shadow-lg ring-4 ring-white/10">
                {user?.full_name ? user.full_name.charAt(0).toUpperCase() : 'S'}
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold">
                  {user?.full_name || 'Loksewa Aspirant'}
                </h1>
                <p className="text-xs sm:text-sm text-slate-300">
                  {user?.email || 'Student Account'}
                </p>
                <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-500/20 text-orange-300 border border-orange-500/30">
                  <Target className="w-3.5 h-3.5 text-orange-400" />
                  <span>Target: {user?.target_exam || 'Civil Sub-Engineer (5th Level)'}</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => onNavigate('mcq')}
                className="py-2 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Start New MCQ Test</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dashboard Tabs */}
        <div className="flex border-b border-slate-200 bg-white rounded-t-xl px-4 sm:px-6 mb-6">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'overview'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Progress Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('tests')}
            className={`py-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'tests'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Test History ({studentAttempts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`py-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'bookmarks'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved Library ({savedMaterials.length + savedAffairs.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3.5 px-4 text-xs sm:text-sm font-bold border-b-2 transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'profile'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Profile Settings</span>
          </button>
        </div>

        {/* Tab 1: Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5">
                <span className="text-xs font-semibold text-slate-500 block mb-1">
                  Mock Tests Completed
                </span>
                <span className="text-2xl font-black text-slate-800">{totalTests}</span>
                <p className="text-[11px] text-slate-400 mt-1">Full-length and topic practice</p>
              </div>

              <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5">
                <span className="text-xs font-semibold text-slate-500 block mb-1">
                  Average Accuracy Rate
                </span>
                <span className="text-2xl font-black text-orange-600">{avgScore}%</span>
                <p className="text-[11px] text-slate-400 mt-1">Loksewa pass threshold: 40%</p>
              </div>

              <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5">
                <span className="text-xs font-semibold text-slate-500 block mb-1">
                  Total Questions Practiced
                </span>
                <span className="text-2xl font-black text-slate-800">{totalQuestionsSolved}</span>
                <p className="text-[11px] text-slate-400 mt-1">Across all PSC syllabus units</p>
              </div>
            </div>

            {/* Preparation Roadmap Box */}
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-6">
              <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <Award className="w-4 h-4 text-orange-600" />
                <span>Recommended Daily Study Roadmap</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50">
                  <span className="font-bold text-slate-800 block mb-1">1. Morning (Paper I - GK)</span>
                  <p className="text-slate-600 leading-relaxed">
                    Revise 20 Census 2078 facts, Nepal River classifications, and Constitution Articles 16 to 46.
                  </p>
                </div>

                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50">
                  <span className="font-bold text-slate-800 block mb-1">2. Afternoon (Paper II - Technical)</span>
                  <p className="text-slate-600 leading-relaxed">
                    Review Surveying & Building Materials formulas. Solve 20 past PSC numerical questions.
                  </p>
                </div>

                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50">
                  <span className="font-bold text-slate-800 block mb-1">3. Evening (MCQ Speed Test)</span>
                  <p className="text-slate-600 leading-relaxed">
                    Take a 45-minute timed mock test on Lokesewa Edge to build question-answering stamina.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Test History */}
        {activeTab === 'tests' && (
          <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
            {studentAttempts.length === 0 ? (
              <div className="p-12 text-center">
                <Clock className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-800">No test attempts yet</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Start practicing MCQs to see your performance metrics and mistakes review here.
                </p>
                <button
                  onClick={() => onNavigate('mcq')}
                  className="mt-4 py-2 px-4 bg-orange-600 text-white rounded-lg text-xs font-bold hover:bg-orange-700 transition"
                >
                  Start First Test
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {studentAttempts.map(attempt => {
                  const isPassed = attempt.score_percentage >= 40;
                  return (
                    <div
                      key={attempt.id}
                      className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition"
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              isPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {isPassed ? 'PASSED' : 'NEEDS PRACTICE'}
                          </span>
                          <span className="text-xs font-bold text-slate-900">
                            {attempt.subject_name}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">
                          {new Date(attempt.attempted_at).toLocaleString()} • {attempt.total_questions} Questions
                        </p>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <span className="text-lg font-bold text-slate-900 block">
                            {attempt.score_percentage}%
                          </span>
                          <span className="text-[11px] text-slate-500">
                            {attempt.correct_count} Correct / {attempt.incorrect_count} Wrong
                          </span>
                        </div>

                        <button
                          onClick={() => onNavigate('mcq')}
                          className="py-1.5 px-3 rounded-lg border border-slate-200 text-xs font-semibold hover:bg-slate-100"
                        >
                          Retake
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Saved Bookmarks */}
        {activeTab === 'bookmarks' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-6">
              <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-orange-600" />
                <span>Bookmarked Notes & PDFs ({savedMaterials.length})</span>
              </h3>

              {savedMaterials.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No notes bookmarked yet.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {savedMaterials.map(mat => (
                    <div
                      key={mat.id}
                      onClick={() => onNavigate('materials')}
                      className="p-4 rounded-xl border border-slate-200 hover:border-orange-300 transition cursor-pointer flex flex-col justify-between"
                    >
                      <div>
                        <span className="text-[10px] font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded">
                          {mat.level}
                        </span>
                        <h4 className="font-bold text-xs sm:text-sm text-slate-800 mt-2 line-clamp-2">
                          {mat.title}
                        </h4>
                      </div>
                      <div className="mt-3 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                        <span>{mat.file_size}</span>
                        <span className="text-orange-600 font-semibold flex items-center gap-1">
                          View Material <ArrowRight className="w-3 h-3" />
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-6">
              <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-orange-600" />
                <span>Bookmarked GK & Current Affairs ({savedAffairs.length})</span>
              </h3>

              {savedAffairs.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No current affairs bookmarked yet.</p>
              ) : (
                <div className="space-y-2">
                  {savedAffairs.map(aff => (
                    <div
                      key={aff.id}
                      onClick={() => onNavigate('gk')}
                      className="p-3.5 rounded-lg border border-slate-200 hover:border-orange-300 transition cursor-pointer flex items-center justify-between"
                    >
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500">
                          {aff.category}
                        </span>
                        <h4 className="font-bold text-xs text-slate-800 line-clamp-1">
                          {aff.title}
                        </h4>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 4: Profile Settings */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-6 sm:p-8 max-w-xl">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Personal Information & Study Target
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Manage your PSC target stream to receive tailored recommendations.
            </p>

            {saveSuccess && (
              <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>Profile updated successfully!</span>
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name (पूरा नाम)
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target PSC Examination
                </label>
                <select
                  value={targetExam}
                  onChange={e => setTargetExam(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-white"
                >
                  <option value="Civil Engineering 5th Level">Civil Engineering 5th Level (Sub-Engineer)</option>
                  <option value="Civil Engineering 7th Level">Civil Engineering 7th Level (Engineer)</option>
                  <option value="Nayab Subba (Non-Gazetted 1st)">Nayab Subba (Non-Gazetted 1st)</option>
                  <option value="Kharidar (Non-Gazetted 2nd)">Kharidar (Non-Gazetted 2nd)</option>
                  <option value="Section Officer (Sakha Adhikrit)">Section Officer (Sakha Adhikrit)</option>
                  <option value="Health Services / Staff Nurse">Health Services / Staff Nurse</option>
                  <option value="Nepal Rastra Bank / Banking">Banking & Public Enterprises</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Phone / WhatsApp (Optional)
                </label>
                <input
                  type="text"
                  placeholder="9841..."
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                />
              </div>

              <button
                type="submit"
                className="py-2.5 px-5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg text-xs shadow-xs transition cursor-pointer"
              >
                Save Changes
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

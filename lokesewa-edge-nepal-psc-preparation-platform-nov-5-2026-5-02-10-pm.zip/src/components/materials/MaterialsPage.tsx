import React, { useState, useMemo } from 'react';
import {
  Search,
  BookOpen,
  Filter,
  Download,
  Eye,
  Bookmark,
  Calendar,
  FileText,
  User,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Share2,
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { StudyMaterial, SubjectCategory } from '../../types';
import { PdfViewerModal } from './PdfViewerModal';

interface MaterialsPageProps {
  initialCategory?: SubjectCategory | 'all';
}

export const MaterialsPage: React.FC<MaterialsPageProps> = ({
  initialCategory = 'all',
}) => {
  const { materials, subjects, deleteMaterial, incrementDownload, toggleBookmark, isBookmarked } = useData();
  const { isAdmin } = useAuth();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'title'>('newest');

  // Preview modal state
  const [selectedMaterial, setSelectedMaterial] = useState<StudyMaterial | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);

  // Filtered and sorted materials
  const filteredMaterials = useMemo(() => {
    return materials
      .filter(item => {
        const matchesCategory =
          selectedCategory === 'all' || item.category === selectedCategory;
        const matchesLevel =
          selectedLevel === 'all' ||
          item.level.toLowerCase().includes(selectedLevel.toLowerCase());
        const query = searchQuery.toLowerCase().trim();
        const matchesSearch =
          !query ||
          item.title.toLowerCase().includes(query) ||
          (item.nepali_title && item.nepali_title.toLowerCase().includes(query)) ||
          item.description.toLowerCase().includes(query) ||
          item.tags.some(t => t.toLowerCase().includes(query)) ||
          item.subject_name.toLowerCase().includes(query);

        return matchesCategory && matchesLevel && matchesSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'popular') return b.downloads_count - a.downloads_count;
        if (sortBy === 'title') return a.title.localeCompare(b.title);
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      });
  }, [materials, selectedCategory, selectedLevel, searchQuery, sortBy]);

  const handleOpenPreview = (material: StudyMaterial) => {
    setSelectedMaterial(material);
    setIsViewerOpen(true);
  };

  const handleDownloadDirect = (e: React.MouseEvent, material: StudyMaterial) => {
    e.stopPropagation();
    incrementDownload(material.id);
    const link = document.createElement('a');
    link.href = material.file_url;
    link.target = '_blank';
    link.download = `${material.title.replace(/\s+/g, '_')}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-700 mb-2">
                <BookOpen className="w-3.5 h-3.5" />
                <span>Verified PSC Study Library</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Notes & PDF Materials
              </h1>
              <p className="text-sm text-slate-600 mt-1 max-w-2xl font-nepali">
                नेपाल लोकसेवा आयोगका पाठ्यक्रम अनुसार तयार गरिएका स्तरीय नोट, क्याप्सुल र विगतका हल गरिएका प्रश्नहरू
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">
                Showing <strong className="text-slate-800">{filteredMaterials.length}</strong> of {materials.length} resources
              </span>
            </div>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Search Input */}
            <div className="md:col-span-5 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
              <input
                type="text"
                placeholder="Search by topic, keyword, or Nepali text..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-slate-50/50"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-3 text-xs text-slate-400 hover:text-slate-600"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Category Dropdown */}
            <div className="md:col-span-3">
              <select
                value={selectedCategory}
                onChange={e => setSelectedCategory(e.target.value)}
                className="w-full py-2.5 px-3 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-white"
              >
                <option value="all">All Subjects (सबै विषय)</option>
                <option value="civil_engineering">Civil Engineering (सिभिल इन्जिनियरिङ)</option>
                <option value="nepal_gk">Nepal GK (नेपाल सामान्य ज्ञान)</option>
                <option value="governance_law">Constitution & Governance (संविधान)</option>
                <option value="iq_reasoning">IQ & Reasoning (बौद्धिक परीक्षण)</option>
                <option value="current_affairs">Current Affairs (समसामयिक)</option>
                <option value="world_gk">World GK (विश्व सामान्य ज्ञान)</option>
              </select>
            </div>

            {/* Level Filter */}
            <div className="md:col-span-2">
              <select
                value={selectedLevel}
                onChange={e => setSelectedLevel(e.target.value)}
                className="w-full py-2.5 px-3 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-white"
              >
                <option value="all">All Levels (तह)</option>
                <option value="5th">5th Level (५औँ तह)</option>
                <option value="7th">7th Level (७औँ तह)</option>
                <option value="officer">Section Officer</option>
                <option value="subba">Nayab Subba</option>
                <option value="kharidar">Kharidar</option>
              </select>
            </div>

            {/* Sort Dropdown */}
            <div className="md:col-span-2">
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="w-full py-2.5 px-3 text-xs sm:text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-white"
              >
                <option value="newest">Newest First</option>
                <option value="popular">Most Downloaded</option>
                <option value="title">Alphabetical (A-Z)</option>
              </select>
            </div>
          </div>

          {/* Quick Category Chips */}
          <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 py-1 mr-1">Quick Select:</span>
            {[
              { id: 'all', label: 'All' },
              { id: 'civil_engineering', label: 'Civil Engg' },
              { id: 'nepal_gk', label: 'Nepal GK' },
              { id: 'governance_law', label: 'Constitution 2072' },
              { id: 'iq_reasoning', label: 'IQ Tricks' },
              { id: 'current_affairs', label: 'Current Affairs' },
            ].map(chip => (
              <button
                key={chip.id}
                onClick={() => setSelectedCategory(chip.id)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition cursor-pointer ${
                  selectedCategory === chip.id
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {chip.label}
              </button>
            ))}
          </div>
        </div>

        {/* Materials Grid */}
        {filteredMaterials.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No study notes found</h3>
            <p className="text-xs text-slate-500 mt-1">
              Try adjusting your search terms or filters to explore other syllabus resources.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedLevel('all');
              }}
              className="mt-4 px-4 py-2 bg-orange-600 text-white rounded-lg text-xs font-semibold hover:bg-orange-700 transition"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMaterials.map(mat => {
              const bookmarked = isBookmarked('material', mat.id);

              return (
                <div
                  key={mat.id}
                  onClick={() => handleOpenPreview(mat)}
                  className="bg-white rounded-xl shadow-xs hover:shadow-md border border-slate-200 hover:border-orange-300 transition-all duration-200 flex flex-col justify-between overflow-hidden group cursor-pointer"
                >
                  <div className="p-5">
                    {/* Header tags */}
                    <div className="flex items-center justify-between gap-2 mb-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-orange-100 text-orange-700">
                          {mat.level}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-600 truncate max-w-[140px]">
                          {mat.subject_name}
                        </span>
                      </div>

                      <button
                        onClick={e => {
                          e.stopPropagation();
                          toggleBookmark('material', mat.id);
                        }}
                        className={`p-1.5 rounded-md hover:bg-slate-100 transition ${
                          bookmarked ? 'text-orange-600' : 'text-slate-400'
                        }`}
                        title={bookmarked ? 'Saved' : 'Save bookmark'}
                      >
                        <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-orange-600' : ''}`} />
                      </button>
                    </div>

                    {/* Title */}
                    <h3 className="font-bold text-slate-900 text-base leading-snug group-hover:text-orange-600 transition line-clamp-2">
                      {mat.title}
                    </h3>
                    {mat.nepali_title && (
                      <p className="text-xs text-slate-500 font-nepali mt-1 line-clamp-1">
                        {mat.nepali_title}
                      </p>
                    )}

                    {/* Description preview */}
                    <p className="text-xs text-slate-600 mt-2.5 line-clamp-2 leading-relaxed">
                      {mat.description}
                    </p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1 mt-3">
                      {mat.tags.slice(0, 3).map(tag => (
                        <span
                          key={tag}
                          className="px-1.5 py-0.5 bg-slate-50 text-slate-500 rounded text-[10px]"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="px-5 py-3 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5 text-slate-400" />
                        <span>{mat.page_count} p.</span>
                      </span>
                      <span className="flex items-center gap-1 text-slate-500 font-medium">
                        <Download className="w-3.5 h-3.5 text-slate-400" />
                        <span>{mat.downloads_count}</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {isAdmin && (
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            if (confirm(`Delete material "${mat.title}"?`)) {
                              deleteMaterial(mat.id);
                            }
                          }}
                          className="p-1 rounded text-red-500 hover:bg-red-50"
                          title="Delete note (Admin)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={e => handleDownloadDirect(e, mat)}
                        className="py-1 px-2.5 rounded bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs flex items-center gap-1 shadow-2xs transition cursor-pointer"
                      >
                        <Download className="w-3 h-3" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* PDF Viewer & Details Modal */}
      <PdfViewerModal
        material={selectedMaterial}
        isOpen={isViewerOpen}
        onClose={() => setIsViewerOpen(false)}
      />
    </div>
  );
};

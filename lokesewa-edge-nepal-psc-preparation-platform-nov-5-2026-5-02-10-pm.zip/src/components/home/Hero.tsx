import React from 'react';
import {
  BookOpen,
  CheckSquare,
  Award,
  Users,
  FileText,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Search,
} from 'lucide-react';
import { initialStats } from '../../data/initialData';

interface HeroProps {
  onExploreMaterials: () => void;
  onPracticeMcqs: () => void;
  onSearch: (query: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreMaterials,
  onPracticeMcqs,
  onSearch,
}) => {
  const [searchInput, setSearchInput] = React.useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim());
    }
  };

  return (
    <div className="relative bg-gradient-to-b from-slate-900 via-navy-950 to-slate-900 bg-slate-900 text-white overflow-hidden py-16 sm:py-24 border-b border-slate-800">
      {/* Decorative Background Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-tr from-orange-500/10 via-amber-500/5 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 right-10 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-6">
          {/* Tag Pill */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-white/10 text-orange-400 border border-white/10 backdrop-blur-md animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping"></span>
            <span>Nepal Loksewa (PSC) Preparation Platform</span>
            <span className="text-slate-400">|</span>
            <span className="font-nepali">स्मार्ट तयारी, सफल नतिजा</span>
          </div>

          {/* Main Title & Tagline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Prepare Smart. <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-amber-300 to-orange-500">
              Achieve More.
            </span>
          </h1>

          {/* Description */}
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
            Welcome to <strong className="text-white font-semibold">Lokesewa Edge</strong> — Nepal’s premier interactive study portal for Public Service Commission examinations. Access syllabus-aligned PDF notes, Civil Engineering guides, timed MCQ mock tests, and real-time vacancy alerts.
          </p>

          {/* Search Bar in Hero */}
          <form
            onSubmit={handleSearchSubmit}
            className="max-w-xl mx-auto relative flex items-center shadow-2xl rounded-2xl overflow-hidden bg-white/10 p-1.5 backdrop-blur-md border border-white/20"
          >
            <div className="pl-3.5 text-slate-400">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              placeholder="Search Civil Notes, Census 2078, Constitution, or IQ tricks..."
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              className="w-full bg-transparent px-3 py-2 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              className="py-2.5 px-5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl text-xs sm:text-sm shrink-0 transition flex items-center gap-1 cursor-pointer"
            >
              <span>Search</span>
            </button>
          </form>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={onExploreMaterials}
              className="py-3 px-6 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-orange-600/30 flex items-center gap-2 transition hover:-translate-y-0.5 cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>Explore Study Materials & PDFs</span>
            </button>

            <button
              onClick={onPracticeMcqs}
              className="py-3 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm border border-slate-700 shadow-md flex items-center gap-2 transition hover:-translate-y-0.5 cursor-pointer"
            >
              <CheckSquare className="w-4 h-4 text-orange-400" />
              <span>Practice MCQs & Mock Test</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Target Exam Badges */}
          <div className="pt-6">
            <p className="text-xs uppercase font-bold tracking-wider text-slate-400 mb-3">
              Target PSC Programs
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 text-xs">
              {[
                'Civil Sub-Engineer (5th Level)',
                'Civil Engineer (7th Level)',
                'Nayab Subba',
                'Kharidar',
                'Section Officer',
                'Health & Nursing',
                'Banking & Public Enterprises',
              ].map(badge => (
                <span
                  key={badge}
                  className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-slate-300 font-medium hover:bg-white/10 transition cursor-default"
                >
                  {badge}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Live Counters Metric Bar */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          <div className="bg-white/5 rounded-2xl p-4 sm:p-5 border border-white/10 backdrop-blur-xs text-center">
            <Users className="w-5 h-5 text-orange-400 mx-auto mb-1.5" />
            <span className="text-xl sm:text-2xl font-black text-white block">48,500+</span>
            <span className="text-[11px] text-slate-400 font-medium">Registered Aspirants</span>
          </div>

          <div className="bg-white/5 rounded-2xl p-4 sm:p-5 border border-white/10 backdrop-blur-xs text-center">
            <CheckSquare className="w-5 h-5 text-amber-400 mx-auto mb-1.5" />
            <span className="text-xl sm:text-2xl font-black text-white block">1,250+</span>
            <span className="text-[11px] text-slate-400 font-medium">Curated MCQ Questions</span>
          </div>

          <div className="bg-white/5 rounded-2xl p-4 sm:p-5 border border-white/10 backdrop-blur-xs text-center">
            <FileText className="w-5 h-5 text-blue-400 mx-auto mb-1.5" />
            <span className="text-xl sm:text-2xl font-black text-white block">340+</span>
            <span className="text-[11px] text-slate-400 font-medium">Verified PDF Notes</span>
          </div>

          <div className="bg-white/5 rounded-2xl p-4 sm:p-5 border border-white/10 backdrop-blur-xs text-center">
            <Award className="w-5 h-5 text-emerald-400 mx-auto mb-1.5" />
            <span className="text-xl sm:text-2xl font-black text-white block">3,820+</span>
            <span className="text-[11px] text-slate-400 font-medium">Passed In Written Exam</span>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Shield,
  BookOpen,
  CheckSquare,
  Bell,
  Globe,
  Database,
  Users,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  Save,
  RotateCcw,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import {
  saveRuntimeSupabaseConfig,
  clearRuntimeSupabaseConfig,
  supabaseUrl,
  supabaseAnonKey,
  isSupabaseConfigured,
} from '../../lib/supabase';
import { SubjectCategory, NoticeType } from '../../types';

export const AdminDashboard: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const {
    materials,
    questions,
    notices,
    currentAffairs,
    quizAttempts,
    addMaterial,
    deleteMaterial,
    addQuestion,
    deleteQuestion,
    addNotice,
    deleteNotice,
    addCurrentAffair,
    deleteCurrentAffair,
    resetToSampleData,
  } = useData();

  const [activeTab, setActiveTab] = useState<'overview' | 'materials' | 'mcqs' | 'notices' | 'affairs' | 'database'>('overview');

  // Supabase Config State
  const [inputUrl, setInputUrl] = useState(supabaseUrl);
  const [inputAnonKey, setInputAnonKey] = useState(supabaseAnonKey);
  const [configSavedNotice, setConfigSavedNotice] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  // New Material Form
  const [newMatTitle, setNewMatTitle] = useState('');
  const [newMatNepaliTitle, setNewMatNepaliTitle] = useState('');
  const [newMatCategory, setNewMatCategory] = useState<SubjectCategory>('civil_engineering');
  const [newMatLevel, setNewMatLevel] = useState('5th Level');
  const [newMatDesc, setNewMatDesc] = useState('');
  const [newMatUrl, setNewMatUrl] = useState('https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf');
  const [newMatAuthor, setNewMatAuthor] = useState('Loksewa Edge Editorial');
  const [newMatTags, setNewMatTags] = useState('PSC, Syllabus, 2083');

  // New MCQ Form
  const [newQText, setNewQText] = useState('');
  const [newQNepaliText, setNewQNepaliText] = useState('');
  const [newQCategory, setNewQCategory] = useState<SubjectCategory>('civil_engineering');
  const [newQTopic, setNewQTopic] = useState('General Engineering');
  const [newQLevel, setNewQLevel] = useState('5th Level');
  const [newQExplanation, setNewQExplanation] = useState('');
  const [newQExplanationNepali, setNewQExplanationNepali] = useState('');
  const [newQDiff, setNewQDiff] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [optA, setOptA] = useState({ text: '', textNepali: '', isCorrect: true });
  const [optB, setOptB] = useState({ text: '', textNepali: '', isCorrect: false });
  const [optC, setOptC] = useState({ text: '', textNepali: '', isCorrect: false });
  const [optD, setOptD] = useState({ text: '', textNepali: '', isCorrect: false });

  // New Notice Form
  const [newNotTitle, setNewNotTitle] = useState('');
  const [newNotNepaliTitle, setNewNotNepaliTitle] = useState('');
  const [newNotType, setNewNotType] = useState<NoticeType>('vacancy');
  const [newNotDesc, setNewNotDesc] = useState('');
  const [newNotDeadline, setNewNotDeadline] = useState('');
  const [newNotLink, setNewNotLink] = useState('http://psc.gov.np');

  // Form Message
  const [actionSuccess, setActionSuccess] = useState('');

  const triggerSuccess = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => setActionSuccess(''), 3000);
  };

  const handleCreateMaterial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMatTitle || !newMatDesc) return;

    await addMaterial({
      title: newMatTitle,
      nepali_title: newMatNepaliTitle || undefined,
      subject_id: 'subj-' + newMatCategory,
      subject_name: newMatCategory.replace(/_/g, ' ').toUpperCase(),
      category: newMatCategory,
      level: newMatLevel,
      description: newMatDesc,
      file_url: newMatUrl,
      file_size: '3.2 MB',
      page_count: 48,
      author: newMatAuthor,
      tags: newMatTags.split(',').map(t => t.trim()),
    });

    setNewMatTitle('');
    setNewMatNepaliTitle('');
    setNewMatDesc('');
    triggerSuccess('Study Material published successfully!');
  };

  const handleCreateQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQText || !optA.text || !optB.text) return;

    await addQuestion({
      subject_id: 'subj-' + newQCategory,
      subject_name: newQCategory.replace(/_/g, ' ').toUpperCase(),
      category: newQCategory,
      topic: newQTopic,
      level: newQLevel,
      question_text: newQText,
      question_text_nepali: newQNepaliText || undefined,
      difficulty: newQDiff,
      explanation: newQExplanation,
      explanation_nepali: newQExplanationNepali || undefined,
      options: [
        { id: 'opt-' + Date.now() + '-1', text: optA.text, text_nepali: optA.textNepali, is_correct: optA.isCorrect },
        { id: 'opt-' + Date.now() + '-2', text: optB.text, text_nepali: optB.textNepali, is_correct: optB.isCorrect },
        { id: 'opt-' + Date.now() + '-3', text: optC.text, text_nepali: optC.textNepali, is_correct: optC.isCorrect },
        { id: 'opt-' + Date.now() + '-4', text: optD.text, text_nepali: optD.textNepali, is_correct: optD.isCorrect },
      ],
    });

    setNewQText('');
    setNewQNepaliText('');
    setNewQExplanation('');
    setNewQExplanationNepali('');
    setOptA({ text: '', textNepali: '', isCorrect: true });
    setOptB({ text: '', textNepali: '', isCorrect: false });
    setOptC({ text: '', textNepali: '', isCorrect: false });
    setOptD({ text: '', textNepali: '', isCorrect: false });
    triggerSuccess('MCQ question added to question bank!');
  };

  const handleCreateNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNotTitle || !newNotDesc) return;

    await addNotice({
      title: newNotTitle,
      nepali_title: newNotNepaliTitle || undefined,
      type: newNotType,
      published_date: new Date().toISOString().split('T')[0],
      deadline_date: newNotDeadline || undefined,
      description: newNotDesc,
      external_link: newNotLink,
      is_active: true,
      is_urgent: newNotType === 'vacancy',
    });

    setNewNotTitle('');
    setNewNotNepaliTitle('');
    setNewNotDesc('');
    triggerSuccess('Notice published successfully!');
  };

  const handleSaveSupabaseConfig = (e: React.FormEvent) => {
    e.preventDefault();
    saveRuntimeSupabaseConfig(inputUrl.trim(), inputAnonKey.trim());
  };

  const handleCopySql = () => {
    fetch('/supabase-schema.sql')
      .then(res => res.text())
      .then(sql => {
        navigator.clipboard?.writeText(sql);
        setCopiedSql(true);
        setTimeout(() => setCopiedSql(false), 2000);
      })
      .catch(() => {
        // Fallback
        setCopiedSql(true);
      });
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Admin Header */}
        <div className="bg-slate-900 rounded-2xl shadow-sm text-white p-6 sm:p-8 mb-8 border border-slate-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-bold bg-orange-600 text-white mb-2">
                <Shield className="w-3.5 h-3.5" />
                <span>Admin Master Control Panel</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Lokesewa Edge Administrator
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Manage syllabus study notes, MCQ question banks, examination notices & Supabase PostgreSQL cloud sync.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold border ${
                isSupabaseConfigured()
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
              }`}>
                {isSupabaseConfigured() ? '● Supabase Active' : '○ Local Storage Cache'}
              </span>

              <button
                onClick={() => {
                  if (confirm('Reset all content back to sample Loksewa dataset?')) {
                    resetToSampleData();
                    triggerSuccess('Content reset to standard sample dataset.');
                  }
                }}
                className="py-1 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 flex items-center gap-1 cursor-pointer"
                title="Reset sample data"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Data</span>
              </button>
            </div>
          </div>
        </div>

        {/* Global Action Success Banner */}
        {actionSuccess && (
          <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{actionSuccess}</span>
          </div>
        )}

        {/* Admin Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-white rounded-t-xl px-4 sm:px-6 mb-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'overview'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Platform Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('materials')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'materials'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Study Notes & PDFs ({materials.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('mcqs')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'mcqs'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <CheckSquare className="w-4 h-4" />
            <span>MCQ Question Bank ({questions.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('notices')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'notices'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Notices ({notices.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('database')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'database'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Supabase Database Sync</span>
          </button>
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold block">Total Study Notes</span>
                <span className="text-2xl font-black text-slate-800">{materials.length}</span>
                <span className="text-[11px] text-emerald-600 block mt-1">Available for download</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold block">MCQ Questions</span>
                <span className="text-2xl font-black text-slate-800">{questions.length}</span>
                <span className="text-[11px] text-orange-600 block mt-1">With 4 options & answers</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold block">Notices & Vacancies</span>
                <span className="text-2xl font-black text-slate-800">{notices.length}</span>
                <span className="text-[11px] text-blue-600 block mt-1">Live announcements</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold block">Recorded Test Attempts</span>
                <span className="text-2xl font-black text-slate-800">{quizAttempts.length}</span>
                <span className="text-[11px] text-purple-600 block mt-1">Student mock tests</span>
              </div>
            </div>

            {/* Quick Admin Actions */}
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-bold text-slate-900 text-sm mb-4">Quick Management Actions</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  onClick={() => setActiveTab('materials')}
                  className="p-4 rounded-xl border border-slate-200 hover:border-orange-500 hover:bg-orange-50/30 text-left transition"
                >
                  <BookOpen className="w-5 h-5 text-orange-600 mb-2" />
                  <h4 className="font-bold text-xs text-slate-800">Add Study Note / PDF</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">Publish syllabus capsule or formula guide</p>
                </button>

                <button
                  onClick={() => setActiveTab('mcqs')}
                  className="p-4 rounded-xl border border-slate-200 hover:border-orange-500 hover:bg-orange-50/30 text-left transition"
                >
                  <CheckSquare className="w-5 h-5 text-orange-600 mb-2" />
                  <h4 className="font-bold text-xs text-slate-800">Create MCQ Question</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">Add 4 options and Nepali explanation</p>
                </button>

                <button
                  onClick={() => setActiveTab('notices')}
                  className="p-4 rounded-xl border border-slate-200 hover:border-orange-500 hover:bg-orange-50/30 text-left transition"
                >
                  <Bell className="w-5 h-5 text-orange-600 mb-2" />
                  <h4 className="font-bold text-xs text-slate-800">Publish PSC Vacancy Notice</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">Announce exam dates, routines or results</p>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: STUDY MATERIALS & PDF NOTES */}
        {activeTab === 'materials' && (
          <div className="space-y-6">
            {/* Add New Material Form */}
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-bold text-sm text-slate-900 mb-4 flex items-center gap-2">
                <Plus className="w-4 h-4 text-orange-600" />
                <span>Upload New Study Note / PDF Document</span>
              </h3>

              <form onSubmit={handleCreateMaterial} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Material Title (English) *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Surveying Formulas for Civil Sub-Engineer"
                      value={newMatTitle}
                      onChange={e => setNewMatTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Nepali Title (नेपाली शीर्षक)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. सिभिल सब-इन्जिनियर नापी क्याप्सुल"
                      value={newMatNepaliTitle}
                      onChange={e => setNewMatNepaliTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Subject Category *
                    </label>
                    <select
                      value={newMatCategory}
                      onChange={e => setNewMatCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-white"
                    >
                      <option value="civil_engineering">Civil Engineering</option>
                      <option value="nepal_gk">Nepal GK</option>
                      <option value="governance_law">Constitution & Governance</option>
                      <option value="iq_reasoning">IQ & Logical Reasoning</option>
                      <option value="current_affairs">Current Affairs</option>
                      <option value="world_gk">World GK</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      PSC Exam Level
                    </label>
                    <select
                      value={newMatLevel}
                      onChange={e => setNewMatLevel(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 bg-white"
                    >
                      <option value="5th Level">5th Level (५औँ तह - Sub-Engineer/Subba)</option>
                      <option value="7th Level">7th Level (७औँ तह - Engineer/Officer)</option>
                      <option value="4th Level">4th Level (४औँ तह - Assistant)</option>
                      <option value="All Levels">All Levels (सबै तहका लागि)</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      PDF Document URL / Supabase Storage URL *
                    </label>
                    <input
                      type="url"
                      required
                      placeholder="https://..."
                      value={newMatUrl}
                      onChange={e => setNewMatUrl(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Description & Syllabus Content *
                    </label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Details of key chapters, formulas, and PSC syllabus units..."
                      value={newMatDesc}
                      onChange={e => setNewMatDesc(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="py-2.5 px-5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg text-xs flex items-center gap-2 cursor-pointer shadow-xs transition"
                >
                  <Plus className="w-4 h-4" />
                  <span>Publish Study Material</span>
                </button>
              </form>
            </div>

            {/* List of Existing Materials */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-700 uppercase">
                Published Study Materials ({materials.length})
              </div>

              <div className="divide-y divide-slate-100">
                {materials.map(mat => (
                  <div key={mat.id} className="p-4 flex items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-700">
                          {mat.level}
                        </span>
                        <span className="text-xs font-bold text-slate-800">{mat.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        {mat.subject_name} • {mat.downloads_count} downloads • {mat.page_count} pages
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`Delete material "${mat.title}"?`)) {
                          deleteMaterial(mat.id);
                          triggerSuccess('Material removed.');
                        }
                      }}
                      className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                      title="Delete material"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: MCQ QUESTION BANK */}
        {activeTab === 'mcqs' && (
          <div className="space-y-6">
            {/* Add New Question */}
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-bold text-sm text-slate-900 mb-4 flex items-center gap-2">
                <Plus className="w-4 h-4 text-orange-600" />
                <span>Create New Multiple Choice Question (MCQ)</span>
              </h3>

              <form onSubmit={handleCreateQuestion} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Category *
                    </label>
                    <select
                      value={newQCategory}
                      onChange={e => setNewQCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="civil_engineering">Civil Engineering</option>
                      <option value="nepal_gk">Nepal GK</option>
                      <option value="governance_law">Constitution & Law</option>
                      <option value="iq_reasoning">IQ Reasoning</option>
                      <option value="current_affairs">Current Affairs</option>
                      <option value="world_gk">World GK</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Topic / Syllabus Unit *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Surveying / Compass"
                      value={newQTopic}
                      onChange={e => setNewQTopic(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Difficulty Level
                    </label>
                    <select
                      value={newQDiff}
                      onChange={e => setNewQDiff(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="easy">Easy</option>
                      <option value="medium">Medium</option>
                      <option value="hard">Hard</option>
                    </select>
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Question Text (English) *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. What is the minimum curing period for ordinary Portland cement?"
                      value={newQText}
                      onChange={e => setNewQText(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Nepali Question Text (वैकल्पिक नेपाली प्रश्न)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. साधारण पोर्टल्यान्ड सिमेन्टको न्यूनतम क्युरिङ समय कति हुनुपर्छ?"
                      value={newQNepaliText}
                      onChange={e => setNewQNepaliText(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>

                {/* 4 Options Grid */}
                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3">
                  <span className="text-xs font-bold text-slate-800 uppercase block mb-1">
                    Four Answer Choices (Select the correct radio button)
                  </span>

                  {[
                    { state: optA, set: setOptA, letter: 'A' },
                    { state: optB, set: setOptB, letter: 'B' },
                    { state: optC, set: setOptC, letter: 'C' },
                    { state: optD, set: setOptD, letter: 'D' },
                  ].map(({ state, set, letter }) => (
                    <div key={letter} className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="correct_answer"
                        checked={state.isCorrect}
                        onChange={() => {
                          setOptA(p => ({ ...p, isCorrect: letter === 'A' }));
                          setOptB(p => ({ ...p, isCorrect: letter === 'B' }));
                          setOptC(p => ({ ...p, isCorrect: letter === 'C' }));
                          setOptD(p => ({ ...p, isCorrect: letter === 'D' }));
                        }}
                        className="w-4 h-4 text-orange-600 focus:ring-orange-500"
                      />
                      <span className="text-xs font-bold w-4">{letter}.</span>
                      <input
                        type="text"
                        required
                        placeholder={`Option ${letter} Text`}
                        value={state.text}
                        onChange={e => set(prev => ({ ...prev, text: e.target.value }))}
                        className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                      <input
                        type="text"
                        placeholder={`Nepali (optional)`}
                        value={state.textNepali}
                        onChange={e => set(prev => ({ ...prev, textNepali: e.target.value }))}
                        className="w-1/3 px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  ))}
                </div>

                {/* Explanation */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Official Explanation (व्याख्या) *
                  </label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Provide standard explanation citing PSC IS codes or constitutional articles..."
                    value={newQExplanation}
                    onChange={e => setNewQExplanation(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                  />
                </div>

                <button
                  type="submit"
                  className="py-2.5 px-5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg text-xs flex items-center gap-2 cursor-pointer shadow-xs transition"
                >
                  <Plus className="w-4 h-4" />
                  <span>Save Question to Bank</span>
                </button>
              </form>
            </div>

            {/* Questions Table */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-700 uppercase">
                Active Question Bank ({questions.length})
              </div>

              <div className="divide-y divide-slate-100">
                {questions.map((q, idx) => (
                  <div key={q.id} className="p-4 flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-slate-400">#{idx + 1}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-700">
                          {q.topic}
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-800">{q.question_text}</p>
                      {q.question_text_nepali && (
                        <p className="text-[11px] text-slate-500 font-nepali">{q.question_text_nepali}</p>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        if (confirm('Delete this MCQ question?')) {
                          deleteQuestion(q.id);
                          triggerSuccess('Question deleted.');
                        }
                      }}
                      className="p-1.5 rounded text-red-500 hover:bg-red-50 transition"
                      title="Delete question"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: NOTICES */}
        {activeTab === 'notices' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-bold text-sm text-slate-900 mb-4 flex items-center gap-2">
                <Plus className="w-4 h-4 text-orange-600" />
                <span>Publish New PSC Examination Notice</span>
              </h3>

              <form onSubmit={handleCreateNotice} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Notice Title *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. PSC Federal Vacancy 2083 for 5th Level"
                      value={newNotTitle}
                      onChange={e => setNewNotTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Notice Type
                    </label>
                    <select
                      value={newNotType}
                      onChange={e => setNewNotType(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="vacancy">Vacancy Announcement (पदपूर्ति विज्ञापन)</option>
                      <option value="exam_routine">Exam Routine (परीक्षा तालिका)</option>
                      <option value="result">Exam Result (लिखित परीक्षा नतिजा)</option>
                      <option value="admit_card">Admit Card (प्रवेशपत्र)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Application Deadline (if applicable)
                    </label>
                    <input
                      type="date"
                      value={newNotDeadline}
                      onChange={e => setNewNotDeadline(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Official Portal Link
                    </label>
                    <input
                      type="url"
                      value={newNotLink}
                      onChange={e => setNewNotLink(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Description & Instructions *
                    </label>
                    <textarea
                      rows={3}
                      required
                      value={newNotDesc}
                      onChange={e => setNewNotDesc(e.target.value)}
                      className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="py-2.5 px-5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg text-xs flex items-center gap-2 cursor-pointer shadow-xs transition"
                >
                  <Plus className="w-4 h-4" />
                  <span>Publish Notice</span>
                </button>
              </form>
            </div>
          </div>
        )}

        {/* TAB 5: DATABASE & SUPABASE SYNC */}
        {activeTab === 'database' && (
          <div className="space-y-6">
            {/* Status Card */}
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Database className="w-5 h-5 text-orange-600" />
                    <span>Supabase Cloud Database & Storage Configuration</span>
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
                    Lokesewa Edge natively supports PostgreSQL, Row Level Security (RLS), Supabase Auth, and PDF Storage. You can connect your free-tier Supabase project below.
                  </p>
                </div>

                <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                  isSupabaseConfigured()
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {isSupabaseConfigured() ? 'Connected to Supabase' : 'Offline Mode (Local Cache)'}
                </div>
              </div>

              {/* Form to enter Supabase credentials */}
              <form onSubmit={handleSaveSupabaseConfig} className="mt-6 space-y-4 max-w-xl">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Supabase Project URL (VITE_SUPABASE_URL)
                  </label>
                  <input
                    type="url"
                    placeholder="https://xyzcompany.supabase.co"
                    value={inputUrl}
                    onChange={e => setInputUrl(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Supabase Anon Public API Key (VITE_SUPABASE_ANON_KEY)
                  </label>
                  <input
                    type="password"
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    value={inputAnonKey}
                    onChange={e => setInputAnonKey(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Only provide the anonymous public key (`anon key`). Never provide service-role keys.
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="submit"
                    className="py-2 px-4 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save & Reconnect Supabase</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      clearRuntimeSupabaseConfig();
                      setInputUrl('');
                      setInputAnonKey('');
                    }}
                    className="py-2 px-4 border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold rounded-lg text-xs transition cursor-pointer"
                  >
                    Clear Credentials
                  </button>
                </div>
              </form>
            </div>

            {/* Schema Script Exporter */}
            <div className="bg-slate-900 text-white rounded-xl border border-slate-800 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="font-bold text-sm text-white">
                    PostgreSQL Schema DDL (`supabase-schema.sql`)
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Copy and run this schema in your Supabase SQL Editor to provision all tables, RLS policies, and triggers.
                  </p>
                </div>

                <button
                  onClick={handleCopySql}
                  className="py-1.5 px-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedSql ? 'Copied to Clipboard!' : 'Copy SQL Schema'}</span>
                </button>
              </div>

              <div className="bg-slate-950 p-4 rounded-lg font-mono text-xs text-slate-300 max-h-48 overflow-y-auto border border-slate-800">
                <pre>{`-- LOKESEWA EDGE POSTGRESQL SUPABASE SCHEMA
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'admin')),
    target_exam TEXT DEFAULT 'Civil Engineering 5th Level'
);

CREATE TABLE public.study_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    level TEXT NOT NULL,
    file_url TEXT NOT NULL
);

CREATE TABLE public.mcq_questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    question_text TEXT NOT NULL,
    explanation TEXT NOT NULL,
    difficulty TEXT NOT NULL
);

-- Full schema in /supabase-schema.sql with RLS enabled`}</pre>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

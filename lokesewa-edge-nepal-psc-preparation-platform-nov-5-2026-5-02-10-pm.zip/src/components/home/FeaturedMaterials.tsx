import React from 'react';
import {
  FileText,
  Download,
  Eye,
  Bookmark,
  Calendar,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { StudyMaterial } from '../../types';
import { useData } from '../../context/DataContext';

interface FeaturedMaterialsProps {
  onViewMaterial: (material: StudyMaterial) => void;
  onViewAllMaterials: () => void;
}

export const FeaturedMaterials: React.FC<FeaturedMaterialsProps> = ({
  onViewMaterial,
  onViewAllMaterials,
}) => {
  const { materials, incrementDownload, toggleBookmark, isBookmarked } = useData();

  // Top 4 materials
  const featured = materials.slice(0, 4);

  return (
    <section className="py-12 sm:py-16 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-700 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Free Download Library</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Latest Uploaded Notes & PDF Guides
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 font-nepali mt-1">
              सबैभन्दा बढी डाउनलोड गरिएका र लोकसेवा तयारीका लागि सिफारिस गरिएका सामग्रीहरू
            </p>
          </div>

          <button
            onClick={onViewAllMaterials}
            className="text-xs sm:text-sm font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <span>View All Study Materials</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map(mat => {
            const bookmarked = isBookmarked('material', mat.id);

            return (
              <div
                key={mat.id}
                onClick={() => onViewMaterial(mat)}
                className="bg-white rounded-xl shadow-xs hover:shadow-md border border-slate-200 hover:border-orange-300 transition-all duration-200 flex flex-col justify-between overflow-hidden cursor-pointer group"
              >
                <div className="p-5">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-700">
                      {mat.level}
                    </span>

                    <button
                      onClick={e => {
                        e.stopPropagation();
                        toggleBookmark('material', mat.id);
                      }}
                      className={`p-1 rounded hover:bg-slate-100 transition ${
                        bookmarked ? 'text-orange-600' : 'text-slate-400'
                      }`}
                      title="Bookmark"
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-orange-600' : ''}`} />
                    </button>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-orange-600 transition line-clamp-2 leading-snug">
                    {mat.title}
                  </h3>
                  {mat.nepali_title && (
                    <p className="text-[11px] text-slate-500 font-nepali mt-1 line-clamp-1">
                      {mat.nepali_title}
                    </p>
                  )}

                  <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                    {mat.description}
                  </p>
                </div>

                <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-slate-400" />
                    <span>{mat.file_size}</span>
                  </span>

                  <button
                    onClick={e => {
                      e.stopPropagation();
                      incrementDownload(mat.id);
                      window.open(mat.file_url, '_blank');
                    }}
                    className="py-1 px-2.5 rounded bg-orange-600 hover:bg-orange-700 text-white font-bold text-[11px] flex items-center gap-1 transition"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
